#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAXN = 10010;
bool vis[MAXN];
void init(){
    memset(vis,false,sizeof vis);
    vis[1] = vis[0] = true;
    vis[2] = false;
    for(int i=2;i<MAXN;i++){
        if(!vis[i]){
            for(int j=2*i;j<MAXN;j+=i) {
                vis[j] = true;
            }
        }
    }
}
int tran(int n){
    int shu[10];
    memset(shu,0,sizeof shu);
    int cnt = 0;
    while(n){
        shu[++cnt] = n%10;
        n /= 10;
    }
    int sum = 0;
    for(int i=1;i<=cnt;i++){
        sum += shu[i] * shu[i];
    } 
    return sum;
}
int main(){
    init();
    int T,nc;
    scanf("%d",&T);
    while(T--){
        scanf("%d",&nc);
        printf("%d ",nc);
        int n;
        scanf("%d",&n);
        printf("%d ",nc);
        if(vis[n]){
            puts("NO");
            continue;
        }
        bool flag = false;
        int cnt = 0,tmp;
        while(tmp = tran(n)){
            if(tmp == 1) {
                flag = true;
                break;
            }
            cnt ++;
            n = tmp;
            if(cnt >= 10000) break;
        }
        if(flag) puts("YES");
        else puts("NO");
    }
    return 0;
}
