/*jkrs*/
#include <bits/stdc++.h>
#define ff first
#define ss second
#define clr(_x,_y) memset(_x,_y,sizeof (_x))
#define pt(y) push_back(y)
#define mk(x,y) make_pair(x,y)
#define pof() pop_front()
#define pob() pop_back()
#define puf() push_front()
#define ls p << 1
#define rs p << 1 | 1
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int inf = 0x3f3f3f3f;
const ll linf = 1e18;
const double pi = acos(-1.0);
const int MAXN = 1e4 + 10;
const int MAXM = 1e5 + 10;
const double eps = 1e-8;

bool vis[MAXN];

int isnot[MAXM];
int p;

int ans[MAXN];

int calc(int x)
{
    int sum = 0;
    while (x)
    {
        int a = x % 10;
        x /= 10;
        sum += a * a;
    }
    return sum;
}

bool judge(int x)
{
    clr(vis,0);
    vis[x] = 1;
    isnot[p ++] = x;
    while (x != 1)
    {
        x = calc(x);
        isnot[p ++] = x;
        if (vis[x] && x != 1)
            return 0;
    }
    return 1;
}

bool notprime[MAXN];
void init()
{
    notprime[0]=notprime[1]=true;
    for(int i=2; i<MAXN; i++) if(!notprime[i])
        {
            if(i>MAXN/i)continue;
            for(int j=i*i; j<MAXN; j+=i) notprime[j]=true;
        }
}


int main()
{
    int t;
    scanf("%d",&t);
    init();
    while (t --)
    {
        int k;
        scanf("%d",&k);
        int x;
        scanf("%d",&x);
        if (ans[x])
        {
            printf("%d %d %s\n",k,x,ans[x] == 1 ? "YES" : "NO");
            continue;
        }
        bool flag = 1;
        p = 0;
        if (notprime[x])
            flag = 0;
        else
            flag = judge(x);
        if (!flag)
        {
            for (int i = 0;i < p; ++ i)
                ans[isnot[i]] = -1;
        }
        printf("%d %d %s\n",k,x,flag ? "YES" : "NO");
    }
    return 0;
}
