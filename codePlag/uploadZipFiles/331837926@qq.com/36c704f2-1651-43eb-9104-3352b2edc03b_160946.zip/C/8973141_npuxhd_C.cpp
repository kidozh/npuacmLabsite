#include <iostream>
#include<algorithm>
#include<stdio.h>
#include<string.h>
using namespace std;
const int maxn=1e5+100;
bool pim[maxn];

void get()
{
    memset(pim,1,sizeof(pim));
    pim[1]=0;
    for(int i=2;i<maxn;i++)
    {
        if(pim[i])
        {
            for(int j=2*i;j<maxn;j+=i)
            {
                pim[j]=0;
            }
        }
    }
}

int getnum(int num)
{
    int x=num;
    int ans=0;
    while(x)
    {
        int  flag=x%10;
        ans+=(flag*flag);
        x/=10;
    }
   return ans;
}

bool dfs(int pos,int step)
{
    if(step>=100) return 0;
    if(pos==1) return 1;
    return dfs(getnum(pos),step+1);
}


int main()
{
    int T;
    scanf("%d",&T);
    get();
    while(T--)
    {
        int cnt,num;
        scanf("%d %d",&cnt,&num);
        if(pim[num]&&dfs(num,0))
        {
            printf("%d %d YES\n",cnt,num);
        }
        else
        {
            printf("%d %d NO\n",cnt,num);
        }
    }
    return 0;
}