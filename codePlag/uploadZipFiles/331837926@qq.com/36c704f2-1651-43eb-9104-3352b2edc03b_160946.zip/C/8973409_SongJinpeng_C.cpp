#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

int a[100010]={0};

int main ()
{
    int n,k;
    int i,j;
    int prm[200000];
    for(i=0;i<=100000;i++)
        prm[i]=1;
    for(i=2;i<=100000;i++)
    {
        for(j=2;j<=100000/i;j++)
        {
            prm[i*j]=0;
        }
    }
    prm[0]=prm[1]=0;
    cin>>n;
    while(n--)
    {

        cin>>k;
        int x,y;
        int z;
        cin>>x;
        z=x;
        y=0;
        int tmp;
        memset(a,0,sizeof(a));
        if(prm[x]==0)
        {
            cout<<k<<' '<<z;
            cout<<" NO"<<endl;
                continue;
        }
        while(1)
        {
            y=0;
            while(x)
            {
                tmp=x%10;
                y+=tmp*tmp;
                x/=10;
            }
            if(y==1)
            {
                cout<<k<<' '<<z;
                cout<<" YES"<<endl;
                break;
            }

            if(a[y]==1)
            {
                cout<<k<<' '<<z;
                cout<<" NO"<<endl;
                break;
            }
            else
            {
                a[y]=1;
            }
            x=y;
        }

    }
}
