#include<cstdio>
#include<iostream>
#include<cstring>

using namespace std;

const int maxn = 10010;
bool tab[maxn];
bool vis[maxn];
bool isprime[maxn];

void getprime ()
{
	for(int i= 2; i<= maxn; i++){
		if(isprime[i])
			for(int j= 2; j*i<= maxn; j++)
				isprime[i*j] = 0;
	}
}


bool f (int x)
{
	if(x == 1) return 1;
	if(vis[x]) return tab[x];

	vis[x] = true;

	int temp = x;
	int sum = 0;

	while(temp > 0){
		int t = temp % 10;
		sum += t * t;
		temp /= 10;
	}

	return tab[x] = f(sum);
}

int main ()
{
	memset(isprime, 1, sizeof(isprime));
	isprime[0] = isprime[1] = 0;
	getprime();

	int cas;
	scanf("%d", &cas);

	while(cas--){

		int no;
		cin >> no;
		cout << no << " ";

		int x;
		cin >> x;
		cout << x << " ";

		if(isprime[x]) f(x);
		if(isprime[x] && tab[x]) cout << "YES\n";
		else cout << "NO\n";
	}

	return 0;
}
