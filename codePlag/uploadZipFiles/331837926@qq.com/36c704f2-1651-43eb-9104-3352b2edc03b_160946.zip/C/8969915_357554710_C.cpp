#include<cstdio>
#include<cstring>
#define maxn 10000
using namespace std;

bool isprime[maxn+5];
int ans[maxn+5],tot;

void getprime(int n)
{
    memset(isprime,true,sizeof(isprime));
    isprime[1]=false;
    for(int i=2;i<=n;i++)
    {
        if(isprime[i])
        {
            tot++;
            ans[tot]=i;
        }
        for(int j=1;((j<=tot) && (i*ans[j]<=n));j++)
        {
            isprime[i*ans[j]]=false;
            if(i%ans[j]==0) break;
        }
    }
}

int ishappy(int m)
{
    int maxt=100;
    while(maxt--)
    {
        if(m==1) return 1;
        int nextm=0;
        while(m)
        {
            int tmp=m%10;
            nextm+=tmp*tmp;
            m/=10;
        }
        m=nextm;
    }
    return 0;
}

int judge(int m)
{
    return isprime[m] && ishappy(m);
}

int main()
{
    int T;
    getprime(10000);
    scanf("%d",&T);
    for(int kase=1;kase<=T;kase++)
    {
        int id,m;
        scanf("%d%d",&id,&m);
        printf("%d %d ",id,m);
        if(judge(m))
        {
            printf("YES\n");
        }
        else
        {
            printf("NO\n");
        }
    }
    return 0;
}
