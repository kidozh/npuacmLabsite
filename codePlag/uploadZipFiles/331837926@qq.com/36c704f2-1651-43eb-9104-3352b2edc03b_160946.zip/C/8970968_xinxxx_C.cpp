#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
using namespace std;
bool vis[100005];
bool is_prime(int x)
{
    if(x==1) return false;
    for(int i=2;i*i<=x;i++)
    {
        if(x%i==0) return false;
    }
    return true;
}

int cal(int x)
{
    int sum=0;
    while(x)
    {
        sum+=(x%10)*(x%10);
        x=x/10;
    }
    return sum;
}

int main()
{
    int t,a,kase;
    scanf("%d",&t);
    while(t--)
    {
        memset(vis,false,sizeof(vis));
        bool f=false;
        scanf("%d %d",&kase,&a);
        if(is_prime(a))
        {
           int tmp=a;
           vis[a]=true;
           while(1)
           {
               tmp=cal(tmp);
               if(tmp==1) {f=true;break;}
               else if(vis[tmp]) break;
               vis[tmp]=true;
           }
        }
        if(f) printf("%d %d YES\n",kase,a);
        else printf("%d %d NO\n",kase,a);
    }
    return 0;
}
