#include <iostream>
#include <cstdio>
#include <cmath>
#include <string.h>
#include <string>
using namespace std;
bool f[10005]={false};
bool state[330];
int main()
{
    f[1]=true;
    for(int i=2;i<=100;i++)
        if (!f[i])
            for(int j=2;i*j<=10000;j++)
               f[i*j]=true;
    int p;
    cin>>p;
    for(int C=1;C<=p;C++)
    {
        int k;
        cin>>k;
        int n;
        cin>>n;
        if (f[n])
        {
            cout<<k<<" "<<n<<" NO"<<endl;
            continue;
        }
        bool flag=false;
        int m=n;
        memset(state,false,sizeof(state));
        do
        {
            if (m==1) {flag=true;break;}
            if (m<330) state[m]=true;
            int t=0;
            while (m>0)
            {
                t+=(m%10)*(m%10);
                m/=10;
            }
            m=t;
        }while (!state[m]);
        if (flag) cout<<k<<" "<<n<<" YES"<<endl;
        else cout<<k<<" "<<n<<" NO"<<endl;
    }
    return 0;
}
