#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
int num;
int a[100001];
int pd()
{
 int i,k;
 if (num==1) return -1;
 k=sqrt(num);
 for (i=2;i<=k;i++)
      if (num%i==0) return -1;
 return 1;
}
int js(int p)
{
 int s=0,k;
 while (p){
        k=p%10;
        s+=k*k;
        p/=10;
		  }
 return s;
}
void work()
{int t;
 if (pd()==-1) {cout<<"NO"<<endl;return;}
 memset(a,0,sizeof(a));
 while (a[num]==0){
        a[num]=1;
        t=js(num);
        if (t==1) {cout<<"YES"<<endl;return;}
        else if (a[t]==1) {cout<<"NO"<<endl;return;}
        num=t;
				  }
 cout<<"NO"<<endl;return;
}
int main()
{
 int p,i,k;
 cin>>p;
 for (i=1;i<=p;i++){
      cin>>k>>num;
	  cout<<k<<" "<<num<<" ";     
	  work();       
				   }
      
}