//By Sean Chen
//hi
#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;

int notprime[10005];
int visit[8100];
void prefunc()
{
    notprime[1]=1;
    for (int i=2;i<100;i++)
    {
        if (!notprime[i])
            for (int j=2;j<=(10004)/i;j++)
                notprime[j*i]=1;
    }
    return;
}
int T,P,Case;
int main()
{
    prefunc();
    scanf("%d",&T);
    for (int i=0;i<T;i++)
    {
        scanf("%d%d",&Case,&P);
        printf("%d %d ",Case,P);
        if (notprime[P])
        {
            printf("NO\n");
            continue;
        }
        int p=P;
        int flag=1;memset(visit,0,sizeof(visit));
        while (flag)
        {
            int temp=p;
            //cout<<temp<<endl;
            p=0;
            while (temp>0)
            {
                int a=temp%10;
                temp=temp/10;
                p+=a*a;
            }
            /*cout<<p<<endl;
            system("pause");*/
            if (visit[p])
                flag=0;
            visit[p]=1;
            if (p==1)
                break;
        }
        if (flag)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}
