#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;
int num[30];
bool judge(int num){
    for(int i=2;i*i<=num;i++){
        if(num%i==0)
            return false;
    }
    return true;
}
bool vis[100001];
int main()
{
    int n;
    scanf("%d",&n);
    for(int cases=1;cases<=n;cases++){
        int tmp;
        scanf("%d",&tmp);
        int num;
        scanf("%d",&num);
        memset(vis,0,sizeof(vis));
        if(judge(num)==false||num<7){
            printf("%d %d NO\n",tmp,num);
            continue;
        }
        bool flag=true;
        int a=num;
        while(1){
            if(a==1)
                break;
            else if(vis[a]==true){
                flag=false;
                break;
            }
            else{
                vis[a]=true;
                int sum=0;
                while(a!=0){
                    sum+=(a%10)*(a%10);
                    a/=10;
                }
                a=sum;
            }
        }
        if(flag){
            printf("%d %d YES\n",tmp,num);
        }else{
            printf("%d %d NO\n",tmp,num);
        }
    }
    return 0;
}
