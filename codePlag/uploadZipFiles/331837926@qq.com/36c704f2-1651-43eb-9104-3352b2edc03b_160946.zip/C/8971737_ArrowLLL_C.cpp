#include <bits/stdc++.h>
#include <cstdlib>
using namespace std;

const int maxn(1e4 + 5);
bool isP[maxn];
void creatPr(int n)
{
    int j = sqrt(n);
    memset(isP, true, sizeof(isP));
    for(int i = 2; i <= j + 5; i++) if(isP[i]) {
        for(int k = i * i; k < n; k += i)
            isP[k] = false;
    }
    isP[0] = isP[1] = false;
}

bool panb(int j)
{
    int s[20];
    set<int> ss;
    while(ss.find(j) == ss.end()) {
        ss.insert(j);
        int l = 0;
        while(j > 0) {
            s[l++] = j % 10;
            j /= 10;
        }
        j = 0;
        for(int k = 0; k < l; k++)
            j += s[k] * s[k];
        if(j == 1) return true;
    }
    return false;
}

int main()
{
    int T, t, m;
    creatPr(maxn - 3);
    scanf("%d", &T);
    while(T--) {
        scanf("%d%d", &t, &m);
        printf("%d %d ", t, m);
        printf("%s\n", (isP[m] && panb(m)) ? "YES" : "NO");
    }
    return 0;
}
