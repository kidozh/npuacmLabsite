#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
bool notprime[10001];
void init()
{
	memset(notprime,false,sizeof(notprime));
	notprime[0]=notprime[1]=true;
	for(int i=2;i<10001;i++)
	     if(!notprime[i]){
			if(i>10001/i)continue;
			for(int j=i*i;j<10001;j+=i)
				notprime[j]=true;
	     }
}
int solve(int s,int num)
{
	if(s==1)
		return 1;
	if(num>=200)
	{
		return 0;
	}
	int a1,a2,a3,a4,a5;
	a1=s/10000;
	a2=s/1000%10;
	a3=s/100%10;
	a4=s/10%10;
	a5=s%10;
	return solve(a1*a1+a2*a2+a3*a3+a4*a4+a5*a5,num+1);
}
int main()
{
	int m;

	init();
	scanf("%d",&m);
	while(m--)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		int flag=solve(b,0);
		if(flag&&!notprime[b])
		{
			printf("%d %d YES\n",a,b);
		}
        else  printf("%d %d NO\n",a,b);
	}
	return 0;
}
