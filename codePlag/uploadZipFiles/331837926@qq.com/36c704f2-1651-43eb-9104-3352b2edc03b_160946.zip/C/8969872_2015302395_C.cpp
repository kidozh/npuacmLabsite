#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int maxn = 10005;
int ca,prime[maxn],notprime[maxn],cnt,ak[maxn],vis[maxn];

void init(){
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d %d ",a,b);
    if(notprime[b] == 0 && ak[b] == 1)
        printf("YES\n");
    else    printf("NO\n");
}

void wi(int k){
    int tmp  = k,ans = 0;
    memset(vis,0,sizeof(vis));
    while(ans != 1 && vis[ans] == 0){
        vis[ans] = 1;
        ans = 0;
        while(tmp){
            int o = tmp%10;
            ans += o*o;
            tmp /= 10;
        }
        tmp = ans;
    }
    if(ans == 1)
        ak[k] = 1;
}

void pre(){
    cnt = 0;
    notprime[1] = 1;
    for(int i = 2; i < maxn ; i ++){
        if(notprime[i] == 0){
            prime[cnt++] = i;
            if(i > 10000){
                break;
            }
            for(int j = 2 * i ; j < maxn; j += i){
                notprime[j] = 1;
            }
        }
    }
    for(int i = 0 ; i <cnt ; i++){
        //printf("%d  ",prime[i]);
        wi(prime[i]);
    }
}

int main(){
    int T;
    scanf("%d",&T);
    pre();
    for(ca =1; ca <= T ;ca++){
        init();
    }
}

