#include <bits/stdc++.h>
using namespace std;

int n, cas;
bool prime[10005];
int cnt, a[20];
bool vis[10005];

int factor(int n)
{
	for (cnt = 0; n; n /= 10)
		a[++cnt] = n % 10;
	int ans = 0;
	for (int i = 1; i <= cnt; ++i)
		ans += a[i] * a[i];
	return ans;
}

bool check(int n)
{
	memset(vis, 0, sizeof vis);
	vis[n] = 1;
	while (n > 1)
	{
		n = factor(n);
		if (n == 1) return true;
		if (vis[n]) return false;
		vis[n] = 1;
	}
	return true;
}

int main()
{
	for (int i = 2; i <= 10000; ++i) prime[i] = 1;
	for (int i = 2; i <= 10000; ++i) if (prime[i])
		for (int j = i << 1; j <= 10000; j += i)
			prime[j] = 0;
	int T;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d%d", &cas, &n);
		printf("%d %d ", cas, n);
		puts(prime[n] && check(n) ? "YES" : "NO");
	}
	return 0;
}