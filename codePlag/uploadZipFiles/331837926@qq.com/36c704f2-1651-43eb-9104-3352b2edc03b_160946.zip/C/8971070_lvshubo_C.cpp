#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int used[10001],prime[10001];
int main()
{
    int p,t,i,j,num,mid,flag;
    for(i=2,prime[1]=1;i<10001;i++)
        for(j=2;j*i<10001;j++)
            prime[i*j]=1;
    scanf("%d",&p);
    while(p--){
        memset(used,0,sizeof(used));
        scanf("%d%d",&t,&num);
        printf("%d %d ",t,num);
        if(prime[num])
            printf("NO\n");
        else{
            for(flag=0;!used[num];num=mid){
                used[num]=1;
                if(num==1){
                    flag=1;
                    break;
                }
                mid=0;
                while(num>0){
                    mid+=(num%10)*(num%10);
                    num/=10;
                }
            }
            if(flag)
                printf("YES\n");
            else
                printf("NO\n");
        }
    }
    return 0;
}
