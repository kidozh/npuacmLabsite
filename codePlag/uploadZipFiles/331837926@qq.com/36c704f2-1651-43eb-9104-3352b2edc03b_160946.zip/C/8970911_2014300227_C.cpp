#include <bits/stdc++.h>
using namespace std;
const int maxn=1e4+3;
int vis[maxn];
void dfs(int x)
{
    if(vis[x])return ;
    vis[x]=1;
    int ans=0;
    while(x)
    {
        int tep=x%10;
        x/=10;
        ans=ans+tep*tep;
    }
    dfs(ans);
}
int check(int x)
{
    for(int i=2;i*i<=x;i++)
    {
        if(x%i==0)return 0;
    }
    memset(vis,0,sizeof(vis));
    dfs(x);
    return vis[1];
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        int k,n;
        scanf("%d%d",&k,&n);
        printf("%d %d ",k,n);
        if(check(n)&&n>1)puts("YES");
        else puts("NO");
    }
    return 0;

}
