#include <bits/stdc++.h>
using namespace std;
char vis[810];

bool pr(int x){
    if (x==1) return false;
    for (int i=2;i*i<=x;++i){
        if (x%i==0) return false;
    }
    return true;
}

bool judge(int x){
    if (x==0) return false;
    if (!pr(x)) return false;
    memset(vis, 0, sizeof vis);
    if (x<=800) vis[x]=1;
    int tmp;
    for(;x>1;){
        tmp=x;
        x=0;
        while (tmp){
            x+=(tmp%10)*(tmp%10);
            tmp/=10;
        }
        if (vis[x]) {
            return false;
        }
        vis[x]=1;
    }
    return true;
}

int main(){
    int T, k;
    scanf("%d",&T);
    while (T--){
        scanf("%d", &k);
        int n;
        scanf("%d", &n);
        printf("%d %d %s\n", k, n, judge(n)?"YES":"NO");
    }
    return 0;
}
