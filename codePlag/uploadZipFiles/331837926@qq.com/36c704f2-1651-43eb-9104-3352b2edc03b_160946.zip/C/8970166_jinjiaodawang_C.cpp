#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define debug(a) cout<<a<<endl
#define clr(a) memset(a,0,sizeof(a))
#define clrne(a) memset(a,-1,sizeof(a))
#define clrinf(a) memset(a,0x3f,sizeof(a))
#define clrneinf(a) memset(a,0xc0,sizeof(a))
#define pb(a) push_back(a)
#define maxn 10001
#define mod 1000000007
#define eps 1e-9
#define inf 0x7fffffff
int a;
map<int,bool> mp;
int ok(int a)
{
//    cout<<a<<endl;
    if (mp[a]) return 0;
    mp[a] = 1;
    int i = 0;
    while(a)
    {
        i+=(a%10)*(a%10);
        a/=10;
    }
    if (i==1) return 1;
    else ok(i);
}
int p()
{
    if (a<2) return 0;
    for (int i = 2;i*i<=a;i++)
    {
        if (a%i==0) return 0;
    }
    return 1;
}
int main()
{
//  freopen("in.txt","r",stdin);
//  freopen("out.txt","w",stdout);
    int T;
    scanf("%d",&T);
    while (T--)
    {
        int ans = 0;
        int temp;
        scanf("%d",&temp);
        scanf("%d",&a);
        cout<<temp<<' '<<a<<' ';
        mp.clear();
        if (p()&&ok(a)) cout<<"YES"<<endl;
        else cout<<"NO"<<endl;
    }
    return 0;
}
