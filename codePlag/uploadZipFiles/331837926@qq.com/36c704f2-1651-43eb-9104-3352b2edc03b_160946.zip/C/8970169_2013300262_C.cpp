#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <vector>
using namespace std;
int p,k,a,ans;
bool prime(int x)
{
    if(x<2)return 0;
    for(int i=2;i*i<=x;++i)
        if(!(x%i))return 0;
    return 1;
}
int next(int x)
{
    int ans=0;
    while(x)
    {
        ans+=(x%10)*(x%10);
        x/=10;
    }
    return ans;
}
bool one(int x)
{
    set<int>st;
    st.clear();
    while(x!=1)
    {
        int y=next(x);
        if(st.find(y)!=st.end()&&y!=1)
            return 0;
        x=y;
        st.insert(x);
    }
    return x==1;
}
int main()
{
    while(~scanf("%d",&p))
    {
        while(p--)
        {
            scanf("%d",&k);
            scanf("%d",&a);
            printf("%d %d %s\n",k,a,(prime(a)&&one(a))?"YES":"NO");
        }
    }
    return 0;
}
