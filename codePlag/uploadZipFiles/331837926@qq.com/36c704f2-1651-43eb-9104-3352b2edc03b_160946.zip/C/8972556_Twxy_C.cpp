#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

bool Happy(int x)
{
	int temp;
	int i=0;

	while(x != 1 && i<1000)
	{
		for(temp=0; x>0; x/=10)
			temp += (x%10)*(x%10);

		x = temp;
		i++;
	}

	if(x == 1) return true;
	else return false;
}

int prime[10010]={0};
void Prime()
{
	int i, j;

	for(i=2; i<101; i++)
		for(j=2; j<=10000/i; j++)
			prime[i*j] = 1;

	prime[1] = 1;
}

int main()
{
	int n;
	int th;
	int num;

	Prime();

	cin >> n;

	while(n--)
	{
		cin >> th >> num;
		cout << th << ' ' << num << ' ';

		if(prime[num]==0 && Happy(num)) cout << "YES" << endl;
		else cout << "NO" << endl;
	}

	return 0;
}
