#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<set>
#include<list>
#include<algorithm>
#include<functional>
#include<numeric>

#define lson  rt<<1,l,mid
#define rson  rt<<1|1,mid+1,r
#define rep(i,x,y)  for(int i=x;i<y;i++)
#define rrep(i,x,y)  for(int i=x;i>y;i--)
#define mem(a,x)  memset(a,x,sizeof(a))
#define pb  push_back
#define mp  make_pair
#define fir  first
#define sec  second
#define lb  lower_bound
#define ub  upper_bound

using namespace std;
typedef long long ll;
typedef pair<int,int> p;

int ncase,num,n;

int fun(int x){
	int res=0;
	int tmp;
	while(x){
		tmp=x%10;
		res+=tmp*tmp;
		x=x/10;
	}
	return res;
}

bool isprime(int x){
	if(x==1||x==0){
		return false;
	}
	if(x%2==0){
		return false;
	}
	for(int i=3;i<=x/i;i+=2){
		if(x%i==0){
			return false;
		}
	}
	return true;
}

bool check(int x){
	int cnt=0;
	int y=x;
	while(y!=1&&cnt<1000){
        int res=fun(y);
        if(res==1){
			return true;
        }
        y=res;
        cnt++;
        //printf("%d is false\n",res);
	}
	return false;
}

int main()
{
	scanf("%d",&ncase);
	while(ncase--){
		scanf("%d %d",&num,&n);
		printf("%d %d ",num,n);
		if(isprime(n)&&check(n)){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}
