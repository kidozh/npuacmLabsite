#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>
#include<set>
using namespace std;

int main ()
{
    bool isp[10005];
    memset(isp,1,sizeof(isp));
    isp[0]=isp[1]=0;
    for(int i=2;i<105;i++)
    {
        if(isp[i]) for(int j=i*i;j<10005;j+=i)
        {
            isp[j]=0;
        }
    }

    int P;
    cin>>P;
    while(P--)
    {
        int K;
        scanf("%d",&K);
        int m;
        scanf("%d",&m);
        int mm=m;
        if(!isp[m])
        {
            cout<<K<<' '<<mm<<" NO"<<endl;
        }
        else
        {
            set<int> se;
            se.insert(m);
            int w;
            while(1)
            {
                int s=0;
                while(m)
                {
                    int t=m%10;
                    s+=t*t;
                    m/=10;
                }
                m=s;
                if(m==1)
                {
                    w=1;
                    break;
                }
                if(se.count(m))
                {
                    w=0;
                    break;
                }
                else
                {
                    se.insert(m);
                }
            }
            if(w)cout<<K<<' '<<mm<<" YES"<<endl;
            else cout<<K<<' '<<mm<<" NO"<<endl;
        }
    }
    return 0;
}
