#include<bits/stdc++.h>

#define inf 0x3f3f3f3f

const int maxn=100000;

using namespace std;

int t;

int get(int x){
        int res = 0;
        while(x){
                res += (x%10)*(x%10);
                x/=10;
        }
        return res;
}

int prime[maxn+10];
int ff[maxn+10];
int yes[maxn+10];
int main()
{
       prime[1] = 1;
       int m = sqrt(10000 + 0.5);

       for(int i = 2; i <= m; ++i){
                if(!prime[i]){
                for(int j = i * i; j <= 10000; j += i) prime[j] = 1;
                }
       }
       for(int t = 1; t <= 10000; ++t){
               int hn = t;
               int temp = hn;
               int flag = 0;
               memset(ff, 0 ,sizeof(ff));
                ff[hn] = 1;
                while(hn != 1){
                     hn = get(hn);
                     if(ff[hn]){
                        flag = 1;
                        break;
                     } else ff[hn] = 1;
                }
               if(!flag && !prime[temp])
               yes[temp] = 1;
       }
       scanf("%d",&t);

       while(t--){
               int k,hn;
               scanf("%d%d",&k,&hn);

               if(yes[hn])
               printf("%d %d YES\n",k, hn);
               else printf("%d %d NO\n",k,hn);
       }
    return 0;
}
/*
4
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 0
*/
