#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
int flag[10013];
bool isprime(int nn)
{
    if(nn < 7)
        return false;
    for(int i = 2; i < sqrt(nn)+1; i++)
    {
        if(nn % i == 0)
            return false;
    }
    return true;
}
int main()
{
    int T;
    scanf("%d", &T);
    while(T--)
    {
        memset(flag, 0, sizeof(flag));
        int n;
        scanf("%d", &n);
        int num;
        scanf("%d", &num);
        if(isprime(num))
        {
            int numm = num;
            while(numm != 0 && numm != 1 && numm != 2 && numm != 3)
            {
                if(flag[numm] == 1)
                    break;
                flag[numm] = 1;
                int a = numm / 1000;
                int b = (numm % 1000) / 100;
                int c = (numm % 100) / 10;
                int d = numm % 10;
                numm = a * a + b * b + c * c + d* d;

               // printf("%d***\n", numm);
            }

            if(numm == 1)
                 printf("%d %d YES\n", n, num);
            else
                 printf("%d %d NO\n", n, num);

        }

        else
            printf("%d %d NO\n", n, num);


    }
}
