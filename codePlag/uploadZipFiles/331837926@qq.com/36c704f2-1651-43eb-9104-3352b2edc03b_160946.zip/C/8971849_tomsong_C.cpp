#include <iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int prime[10010],happy[10010];
int isprime(int n)
{
    if(prime[n]==0)
    {
        for(int i=2;i<=n/i;i++)
        {
            if(n%i==0) {prime[n]=-1;return prime[n];}
        }
        prime[n]=1;
    }
    return prime[n];
}
int ishappy(int n)
{
    if(n==1) return 1;
    if(happy[n]==2) happy[n]=-1;
    if(happy[n]==0)
    {
        happy[n]=2;
        happy[n]=ishappy((n%10)*(n%10)+(n/10%10)*(n/10%10)+(n/100%10)*(n/100%10)+(n/1000)*(n/1000));
    }
    return happy[n];
}
int main()
{
    int T,t,c,n;
    memset(prime,0,sizeof(prime));
    memset(happy,0,sizeof(happy));
    prime[1]=-1;
    scanf("%d",&T);
    for(t=1;t<=T;t++)
    {
        scanf("%d %d",&c,&n);
        printf("%d %d ",t,n);


        if(isprime(n)==1&&ishappy(n)==1)
            printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
