#include <stdio.h>
#include <iostream>
#include <string.h>
using namespace std ;
#define MAX 100000
int prime[MAX] ={0};
int visit[MAX] ;
void init()
{
    prime[0] = 1 ;
    prime[1] = 1 ;
    for(int i = 2 ; i < MAX ; i ++)
    {
        if(!prime[i])
        {
            for(int j = i*2 ; j < MAX ; j += i)
            {
                prime[j] = 1 ;
            }
        }
    }
}
int main()
{
    int n  , k ,num , temp , tt,nn;
    cin >> n ;
    init() ;
    while(n --)
    {
        cin >> k >> num ;
        nn = num ;
        memset(visit , 0 , sizeof(visit)) ;
        if(prime[num] == 1)
        {
            cout << k << ' '<< num << ' '<<"NO"<<endl;
        }
        else
        {
            int flag = 0 ,step = 0;
            {
                while(!visit[num])
                {
                    //cout << num << endl;
                    visit[num] = 1 ;
                    temp = 0 ;
                    tt = 0 ;
                        while(num != 0)
                        {
                            tt = num%10 ;
                            temp += (tt*tt) ;
                            num /= 10 ;
                        }
                    if(temp == 1) {
                            //cout <<"**"<<endl;
                            break ;
                    }
                    num = temp ;
                    //visit[temp] = 1 ;
                }
                if(temp == 1)
                    cout <<k << ' '<<nn<<" "<<"YES"<<endl;
                else
                   cout <<k << ' '<<nn<<" "<<"NO"<<endl;
            }

        }
    }
    return 0 ;
}
