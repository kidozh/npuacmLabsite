#include<iostream>
#include<string.h>
using namespace std;
bool isapp[1000];
int next(int num)
{
    int ans=0;
    while(num>0)
    {
        int t=num%10;
        ans+=t*t;
        num/=10;
    }
    return ans;
}
bool isprime(int num)
{
    if(num==1)return false;
    for(int i=2;i*i<=num;i++)
    {
        if(num%i==0)
        return false;
    }
    return true;
}
int main()
{
    int p,k,t;
    cin>>p;
    for(int i=1;i<=p;i++)
    {
        cin>>k;
        cin>>t;
        cout<<i<<" "<<t<<" ";
        memset(isapp,0,sizeof(isapp));
        if(isprime(t))
        {
            int flag=false;
            t=next(t);
            while(isapp[t]==false)
            {
                isapp[t]=true;
                if(t==1)
                {
                    cout<<"YES"<<endl;
                    flag=true;
                    break;
                }
                t=next(t);
            }
            if(flag==false)
            {
                cout<<"NO"<<endl;
            }
        }
        else
        {
            cout<<"NO"<<endl;
            continue;
        }
    }
    return 0;
}