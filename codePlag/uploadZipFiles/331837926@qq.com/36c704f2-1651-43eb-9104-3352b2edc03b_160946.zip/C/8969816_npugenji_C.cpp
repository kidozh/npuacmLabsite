#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <string>
#define N 50010
#define M 50010
using namespace std;
int p[N],cnt;
bool vis[M],show[5000];
void Prime(int bound, int &num)
{
    memset(vis,0,sizeof vis);
    num = 0;
    for(int i=2; i<bound; ++i)
    {
        if(!vis[i]) p[num++]=i;
        for(int j=0;j<num && i*p[j]<bound;++j)
        {
            vis[i*p[j]] = 1;
            if(!(i%p[j])) break;
        }
    }
}

bool judge(int m)
{
    int ret=0;
    if (m==1) return true;
    else
    {
        while (m>0)
        {
            ret+=(m%10)*(m%10);
            m/=10;
        }
        if (show[ret])
            return false;
        else
        {
            show[ret]=true;
            return judge(ret);
        }
    }
}

int main()
{
    Prime(50000,cnt);
    int t;
    cin>>t;
    int k,m;
    while (t--)
    {
        scanf("%d%d",&k,&m);
        if (!vis[m] && m!=1)
        {
            memset(show,0,sizeof show);
            if (judge(m))
                printf("%d %d YES\n",k,m);
            else
                printf("%d %d NO\n",k,m);
        }
        else
            printf("%d %d NO\n",k,m);
    }
    return 0;
}
