#include <iostream>
#include <cstdio>
#include <cmath>
#include <string.h>
#include <string>
using namespace std;
int dp[2005][505]={0};
int main()
{
    dp[1][0]=1;dp[1][1]=1;
    for(int i=2;i<=2000;i++)
    {
        for(int j=0;j<=dp[i-1][0];j++)
            dp[i][j]=dp[i-1][j];
        int l=1;
        while (dp[i][l]!=0)
        {
            dp[i][l]--;
            l++;
        }
        dp[i][l]=l;
        if (l>dp[i][0]) dp[i][0]=l;
    }
    int p;
    cin>>p;
    for (int C=1;C<=p;C++)
    {
        int k,n;
        cin>>k>>n;
        cout<<k<<" "<<dp[n][0]<<endl;
        for(int i=1;i<=dp[n][0]-1;i++)
        {
            cout<<dp[n][i];
            if (i%10==0) cout<<endl;else cout<<" ";
        }
        cout<<dp[n][dp[n][0]]<<endl;
    }
}
