#include<cstdio>
#include<vector>
#define maxn 80
using namespace std;

int n;
int ans[maxn+5];

void solve(int sum)
{
    n=1;
    ans[1]=1;
    if(sum==1)
    {
        return;
    }
    sum--;

    int fz=-1;
    while(sum--)
    {
        if(fz==-1)
        {
            for(int i=1;i<=n;i++) ans[i]--;
            ans[n+1]=n+1;
            n++;
            fz=1;
        }
        else
        {
            ans[fz]=fz;
            int flag=0;
            for(int i=fz-1;i>=1;i--)
            {
                ans[i]--;
                if(ans[i]==0)
                {
                    flag=1;
                    fz=i;
                }
            }
            if(!flag)
            {
                int found=0;
                for(int i=fz+1;i<=n;i++)
                {
                    if(ans[i]==0)
                    {
                        found=1;
                        fz=i;
                        break;
                    }
                }
                if(!found) fz=-1;
            }
        }
    }
}

int main()
{
    int T,id,sum;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d",&id,&sum);
        printf("%d ",id);
        solve(sum);
        printf("%d\n",n);

        for(int i=1;i<=n;i++)
        {
            printf("%d",ans[i]);
            if(i%10==0) printf("\n");
            else if(i!=n) printf(" ");
        }
        if(n%10!=0) printf("\n");
    }
    return 0;
}
