#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <vector>
using namespace std;
int tmp[1000];
void solve(int id,int x)
{
    memset(tmp,0,sizeof(tmp));
    tmp[0]=x;
    for(int k=1;k<=x;++k)
    {
        int i;
        for(i=0;;++i)
            if(!tmp[i])
                break;
        tmp[i]+=i;
        for(--i;~i;--i)--tmp[i];
    }
    int j;
    for(j=999;~j;--j)if(tmp[j])break;
    printf("%d %d\n",id,j);
    for(int i=1;i<=j;++i)
        printf("%d%c",tmp[i],((i==j)||!(i%10))?'\n':' ');
}
int main()
{
    int p,k,n;
    while(~scanf("%d",&p))
    {
        while(p--)
        {
            scanf("%d%d",&k,&n);
            solve(k,n);
        }
    }
    return 0;
}
