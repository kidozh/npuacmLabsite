#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
using namespace std;

int a[2001][101]={0};
int len[2001]={0};

int main ()
{

    len[0]=1;
    for(int i=1;i<2001;i++)
    {
        int j;
        for(j=1;j<=100;j++)
        {
            a[i][j]=a[i-1][j];
        }
        len[i]=len[i-1];
        for(j=1;j<=len[i];j++)
        {
            if(a[i][j]!=0)
            {
                a[i][j]--;
            }
            else
            {
                a[i][j]=j;
                break;
            }
        }
        if(j==len[i]+1)
        {
            len[i]++;
            a[i][j]=j;
        }
    }

    int P;
    cin>>P;
    while(P--)
    {
        int K,N;
        scanf("%d%d",&K,&N);
        cout<<K<<' '<<len[N]<<endl;
        for(int i=1;i<=len[N];i++)
        {
            if((i-1)%10)cout<<' ';
            cout<<a[N][i];
            if(i%10==0)cout<<endl;
        }
        if(len[N]%10) cout<<endl;
    }
    return 0;
}
