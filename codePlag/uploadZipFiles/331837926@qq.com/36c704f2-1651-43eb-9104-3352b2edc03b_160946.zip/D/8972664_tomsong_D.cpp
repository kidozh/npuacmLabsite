#include <iostream>
#include<cstdio>
#include<cstring>
using namespace std;
short s[2010][81];
short e[2010];
void fun()
{
    for(int n=1;n<=2000;n++)
    {
        int i=1;
        while(s[n][i]>0&&i<=e[n]) i++;
        if(i==e[n]+1)
        {
            e[n+1]=i;
            s[n+1][i]=i;
            for(int j=1;j<=e[n];j++)
            {
                s[n+1][j]=s[n][j]-1;
            }
        }
        else
        {
            e[n+1]=e[n];
            s[n+1][i]=i;
            for(int j=1;j<i;j++)
            {
                s[n+1][j]=s[n][j]-1;
            }
            for(int j=i+1;j<=e[n+1];j++)
                s[n+1][j]=s[n][j];
        }
    }
}
int main()
{
    memset(s,0,sizeof(s));
    memset(e,0,sizeof(e));
    s[1][1]=1;e[1]=1;
    fun();
    int T,t,t_,n;
    scanf("%d",&T);
    for(t=1;t<=T;t++)
    {
        scanf("%d %d",&t_,&n);
        printf("%d %d\n",t,e[n]);
        for(int i=1;i<e[n];i++)
        {
            printf("%d",s[n][i]);
            if(i%10==0) printf("\n");
            else printf(" ");
        }
        printf("%d\n",s[n][e[n]]);
    }
    return 0;
}
