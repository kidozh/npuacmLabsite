#include <iostream>
#include <algorithm>
#include <string.h>
using namespace std;
int dig[81];
bool distribute(int i)
{
    for (int j = i - 1; j >= 0; j++)
    {
        if (dig[j] == 0)
            distribute(j);
    }
    for (int j = 0; j < i; j++)
    {
        dig[j]--;
    }
    dig[i] = i;
    return true;
}
int main()
{
    int p, k;
    cin >> p;
    for (int i = 1; i <= p; i++)
    {
        cin >> k;
        memset(dig, 0, sizeof(dig));
        cin >> dig[0];
        while (dig[0] != 0)
        {
            int j = 1;
            while (dig[j] >= 1)
                j++;
            for (int k = 0; k < j; k++)
                dig[k]--;
            dig[j] = j;
        }
        int ind = 80;
        while (dig[ind] == 0)
            ind--;
        cout << i << " " << ind << endl;
        for (int k = 1; k <= ind; k++)
        {
            cout << dig[k];
            if(k==ind)cout<<endl;
            else if (k % 10 == 0)
                cout<<endl;
            else cout<<" ";
        }
    }
    return 0;
}