#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;
int A[110];
int main()
{
    int n;
    scanf("%d",&n);
    for(int cases=1;cases<=n;cases++){
        int tmp;
        cin>>tmp;
        int num;
        int maxn=0;
        cin>>num;
        memset(A,0,sizeof(A));
        while(num){
            bool flag=true;
            for(int i=1;i<=maxn;i++){
                if(A[i]==0){
                    num--;
                    for(int j=1;j<i;j++)
                        A[j]--;
                    A[i]=i;
                    flag=false;
                    break;
                }
            }
            if(flag){
                for(int i=1;i<=maxn;i++)
                    A[i]--;
                num--;
                maxn++;
                A[maxn]=maxn;
            }
        }
        cout<<tmp<<" "<<maxn<<endl;
        for(int i=1;i<=maxn;i++){
            if(i%10!=0&&i!=maxn){
                cout<<A[i]<<" ";
            }else
                cout<<A[i]<<endl;
        }
    }
    return 0;
}

