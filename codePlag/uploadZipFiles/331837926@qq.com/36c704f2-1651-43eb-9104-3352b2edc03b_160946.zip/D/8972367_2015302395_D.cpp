#include <cstdio>
#include <iostream>
#include <cstring>
int ca;
using namespace std;
int n,a[100];

void init(){
    scanf("%d",&n);
    memset(a,0,sizeof(a));
    a[0] = n;
    while(a[0]){
        for(int i = 0; i <= 80 ; i++){
            if(a[i]==0){
                a[i] = i;
                break;
            }
            a[i]--;
        }
    }
    int mas = 0;
    for(int i = 1; i <= 90 ; i++){
        if(a[i]){
            mas = i;
        }
    }
    printf("%d %d\n",ca,mas);
    int cnt = 0;
    for(int i = 1 ; i <= mas ; i++){
        cnt++;
        if(cnt == 10){
            cnt = 0;
            printf("%d\n",a[i]);
        }
        else printf("%d%c",a[i],i == mas?'\n':' ');
    }
}
int main(){
    int T;
    scanf("%d",&T);
    for(ca = 1; ca <= T;ca++){
        int p;
        scanf("%d",&p);
        init();
    }
}
/*
3
1 4
2 57
3 500
*/
