/*jkrs*/
#include <bits/stdc++.h>
#define ff first
#define ss second
#define clr(_x,_y) memset(_x,_y,sizeof (_x))
#define pt(y) push_back(y)
#define mk(x,y) make_pair(x,y)
#define pof() pop_front()
#define pob() pop_back()
#define puf() push_front()
#define ls p << 1
#define rs p << 1 | 1
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int inf = 0x3f3f3f3f;
const ll linf = 1e18;
const double pi = acos(-1.0);
const int MAXN = 2e3 + 10;
const int MAXM = 1e5 + 10;
const double eps = 1e-8;

vector <int> g[MAXN];

void init()
{
    g[1].pt(1);
    for (int i = 2;i <= 2e3; ++ i)
    {
        int cur = -1;
//        int now = -1;
        for (int j = 0;j < g[i - 1].size(); ++ j)
        {
            if (g[i - 1][j] == 0)
            {
                cur = j;
                break;
            }
//            else if (g[i - 1][j] == j && now == -1)
//            {
//                now = j;
//            }
        }
        if (cur != -1)
        {
            for (int j = 0;j < cur; ++ j)
                g[i].pt(g[i - 1][j] - 1);
            g[i].pt(cur + 1);
            for (int j = cur + 1;j < g[i - 1].size(); ++ j)
                g[i].pt(g[i - 1][j]);
        }
//        else if (now != -1)
//        {
//            for (int j = 0;j < now; ++ j)
//                g[i].pt(g[i - 1][j]);
//            g[i].pt(now + 1);
//            for (int j = now + 1;j < g[i - 1].size(); ++ j)
//                g[i].pt(g[i - 1][j]);
//        }
        else
        {
            for (int j = 0;j < g[i - 1].size(); ++ j)
                g[i].pt(g[i - 1][j] - 1);
            g[i].pt(g[i - 1].size() + 1);
        }
    }
}

int main()
{
//    freopen("in.txt","r",stdin);
    int t;
    scanf("%d",&t);
    init();
    while (t --)
    {
        int k;
        scanf("%d",&k);
        int n;
        scanf("%d",&n);
        printf("%d %d\n",k,g[n].size());
        for (int i = 0;i < g[n].size(); ++ i)
            printf("%d%c",g[n][i],(i + 1) % 10 == 0 || i == g[n].size() - 1 ? '\n' : ' ');
    }
    return 0;
}
