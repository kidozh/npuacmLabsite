#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define debug(a) cout<<a<<endl
#define clr(a) memset(a,0,sizeof(a))
#define clrne(a) memset(a,-1,sizeof(a))
#define clrinf(a) memset(a,0x3f,sizeof(a))
#define clrneinf(a) memset(a,0xc0,sizeof(a))
#define pb(a) push_back(a)
#define mp(a,b) make_pair(a,b)
#define mod 1000000007
#define eps 1e-9
#define inf 0x7fffffff
#define pr pair<int,int>
int a[100];
void solve(int n)
{
    clr(a);
    a[0] = n;
    while (a[0])
    {
        int cnt = 0;
        for (; a[cnt]!=0; cnt++);
        a[cnt] += cnt;
        for (int i = 0; i<cnt; i++)
            a[i]--;
//        cout<<cnt<<endl;
    }
}
int main()
{
//  freopen("in.txt","r",stdin);
//  freopen("out.txt","w",stdout);
    int T;
    scanf("%d",&T);
    while (T--)
    {
        int temp;
        scanf("%d",&temp);
        int n;
        scanf("%d",&n);
        solve(n);
//        cout<<'!'<<endl;
        for (int  i = 99;; i--)
        {
            if (a[i])
            {
                n = i;
                break;
            }
        }
        cout<<temp<<' '<<n<<endl;
        int line = 0;
        for (int i = 1; i<=n; i++)
        {
            printf("%d",a[i]);
            line++;
            if (line==10||i==n)
            {
                line = 0;
                cout<<endl;
            }

            else cout<<' ';
        }
    }
    return 0;
}
