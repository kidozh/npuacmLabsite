#include <bits/stdc++.h>

using namespace std;
const int maxn(2005);
vector<int> xuL[maxn];
typedef vector<int>::iterator vit;

int main()
{
    int n = 2002;
    xuL[1].push_back(1);
    for(int i = 1; i < n; i++) {
        int l = xuL[i].size(), j, k;
        for(j = 0; j < l; j++) {
            if(!xuL[i][j]) {
                break;
            }
            xuL[i + 1].push_back(xuL[i][j] - 1);
        }
        xuL[i + 1].push_back(j + 1);
        for(k = j + 1; k < l; k++) {
            xuL[i + 1].push_back(xuL[i][k]);
        }
    }
    int T;
    //freopen("data.in", "r", stdin);
    scanf("%d", &T);
    while(T--) {
        int t;
        scanf("%d%d", &t, &n);
        printf("%d %d\n", t, xuL[n].size());
        vit p = xuL[n].begin();
        while(p < xuL[n].end()) {
            int m = 9;
            printf("%d", *p++);
            while(m-- && p < xuL[n].end()) {
                printf(" %d", *p++);
            }
            puts("");
        }
    }
    return 0;
}
