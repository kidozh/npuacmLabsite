#include <bits/stdc++.h>
using namespace std;
const int N = 2003;

int len[N];
int a[N][85];

void initI(int n)
{
	memcpy(a[n], a[n-1], 85 << 2);
	len[n] = len[n-1];
	for (int i = 1; i <= len[n]; ++i)
		if (a[n-1][i] == 0)
		{
			for (int j = 1; j < i; ++j)
				--a[n][j];
			a[n][i] = i;
			return;
		}
	++len[n];
	for (int i = 1; i < len[n]; ++i)
		--a[n][i];
	a[n][len[n]] = len[n];
}

void init()
{
	len[1] = 1;
	a[1][1] = 1;
	for (int i = 2; i <= 2000; ++i)
		initI(i);
}

int main()
{
	init();
	int T, n, cas;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d %d", &cas, &n);
		printf("%d %d\n", cas, len[n]);
		for (int i = 1; i <= len[n]; ++i)
		{
			printf("%d", a[n][i]);
			if (i == len[n]) putchar('\n');
			else
			{
				if (i % 10 == 0) putchar('\n');
				else putchar(' ');
			}
		}
	}
	return 0;
}
