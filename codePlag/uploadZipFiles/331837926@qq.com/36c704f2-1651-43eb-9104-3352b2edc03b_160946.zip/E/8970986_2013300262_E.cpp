#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <vector>
using namespace std;
int p,k,a,b;
void solve(int a,int b)
{
    if(b==1)
    {
        printf("1/%d\n",a+1);
        return;
    }
    int cnt=a/b;
    a%=b;
    b-=a;
    a+=b;
    b+=cnt*a;
    printf("%d/%d\n",a,b);
}
int main()
{
    while(~scanf("%d",&p))
    {
        while(p--)
        {
            scanf("%d %d/%d",&k,&a,&b);
            printf("%d ",k);
            solve(a,b);
        }
    }
    return 0;
}
