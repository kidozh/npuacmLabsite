#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;

int main()
{
	int T;
	scanf("%d", &T);
	while(T--)
	{

		int n;
		scanf("%d", &n);
		long long x,y;
		scanf("%lld/%lld",&x,&y);
		long long t;
		if(x==y)printf("%d 1/2\n",n);
		else
		{
			t = x / y;
            if(x < y)
                printf("%d %lld/%lld\n",n ,y ,y-x);
            else
                printf("%d %lld/%lld\n",n, y ,(y-x+2*t*y));
		}
	}
	return 0;
}
