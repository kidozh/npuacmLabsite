#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <string>

using namespace std;
int p,q,a,b,k,cnt;

int main()
{
    int t;
    cin>>t;
    while (t--)
    {
        cnt=0;
        scanf("%d %d/%d",&k,&a,&b);
        if (a==1 && b==1)
        {
            printf("%d 1/2\n",k);
            continue;
        }
        cnt=(a-b)/b;
        a=a-cnt*b;
        if (a>b) {a-=b;cnt++;}
        if (a==1 && b==1)
            cnt++;
        else
        {
            q=b-a;p=b-q;
            a=p+q;b=q;
        }
        b=a*cnt+b;
        printf("%d %d/%d\n",k,a,b);
    }
    return 0;
}
