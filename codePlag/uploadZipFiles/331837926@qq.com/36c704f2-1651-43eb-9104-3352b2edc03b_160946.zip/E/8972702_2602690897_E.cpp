#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
void myfind(long long & a,long long& b)
 {
    int d=0;
    if(a%b==0)
    {
        d=a/b-1;
        a=b;
    }
    else 
    {
        d=(a-a%b)/b;
        a=a%b;
    }
    if(!(a==1&&b==1))
    {
        b-=a;
        a+=b;
        b+=a*d;
    }
    else
    {
            b+=a*(d+1);
    }
 }
int main()
{
    int p,k;
    long long a,b;
    char t;
    scanf("%d",&p);
    for(int i=1;i<=p;i++)
    {
        scanf("%d",&k);
        scanf("%lld/%lld",&a,&b);
        myfind(a,b);
        printf("%d %lld/%lld\n",k,a,b);
    }
    return 0;
}