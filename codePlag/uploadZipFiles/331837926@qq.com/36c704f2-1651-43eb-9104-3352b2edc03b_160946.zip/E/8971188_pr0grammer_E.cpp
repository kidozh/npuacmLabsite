#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a; }

int main()
{
	int T, cas;
	ll p, q;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d%lld/%lld", &cas, &p, &q);
		//ll g = gcd(p, q);
		//p /= g; q /= g;
		printf("%d ", cas);
		if (p == 1 && q == 1)
		{
			puts("1/2");
			continue;
		}
		else if (q == 1)
		{
			printf("1/%lld\n", p + 1);
			continue;
		}
		int cnt = 0;
		while (p > q)
		{
			p -= q;
			++cnt;
		}
		q -= p;
		p += q;
		while (cnt--)
		{
			q += p;
		}
		printf("%lld/%lld\n", p, q);
	}
	return 0;
}