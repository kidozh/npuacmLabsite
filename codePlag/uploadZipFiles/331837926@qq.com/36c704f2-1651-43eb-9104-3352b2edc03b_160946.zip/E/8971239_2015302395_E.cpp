#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
using namespace std;
int ca;
long long a,b;
typedef long long LL;
void get(LL a,LL b){
    int cnt = 0;
    while(a > b){
        a = a-b;
        //b = b;
        cnt++;
    }
   // cerr <<"a = "<<a<<"  b = "<<b<<endl;
    LL tmp = b;
    b = b-a;
    a = tmp;

    while(cnt){
        cnt--;
        a = a;
        b = a+b;
    }
    cout <<a<<"/"<<b<<endl;
}

void init(){
    string s;
    cin>>s;
    // cout <<"asd "<<b<<endl;
    sscanf(s.c_str(),"%lld/%lld",&a,&b);
    printf("%d ",ca);
    if(a < b ){
        //cerr <<"a = "<<a<<"  b = "<<b<<endl;
        cout <<b<<"/"<<b-a<<endl;
    }
    else if(b==1){
        cout <<"1/"<<a+1<<endl;
    }
    else{
        get(a,b);
    }
}

int main(){
    int T;
    scanf("%d",&T);
    for(ca = 1; ca <= T;ca++){
        int p;
        scanf("%d",&p);
        init();
    }
}
/*
5
1 1/1
2 1/3
3 5/2
4 2178309/1346269
5 1/10000000
*/
