#include <iostream>
#include<cstdio>
using namespace std;

int p,q,lv;
void fa()
{
    if(p<q) q-=p;
    else p-=q;
}
void ls(){q+=p;}
void rs(){p+=q;}
void fun0()
{

}
void fun()
{
    if(q==1)
    {
        q=p+1;
        p=1;
        return;
    }

    lv=0;
    while(p>q) {fa();lv++;}

    fa();rs();

    while(lv--) ls();
}

int main()
{
    int T,t,c;
    scanf("%d",&T);
    for(t=1;t<=T;t++)
    {

        scanf("%d %d/%d",&c,&p,&q);

        fun();

        printf("%d %d/%d\n",t,p,q);
    }
    return 0;
}
