#include<cstdio>
using namespace std;

void solve(long long p,long long q)
{
    if(p==q)
    {
        printf("1/2\n");
        return;
    }
    if(p<q)
    {
        printf("%lld/%lld\n",q,q-p);
        return;
    }
    if(p>q)
    {
        if(q==1)
        {
            printf("1/%lld\n",p+1);
            return;
        }
        int cnt=0;
        long long nextp=p,nextq=q;
        while(nextp>nextq)
        {
            nextp=nextp-nextq;
            nextq=nextq;
            cnt++;
        }

        long long pp=nextq,qq=nextq-nextp;
        while(cnt--)
        {
            pp=pp;
            qq=pp+qq;
        }
        printf("%lld/%lld\n",pp,qq);
    }
}

int main()
{
    int T,id;
    scanf("%d",&T);
    while(T--)
    {
        long long p=0,q=0;
        scanf("%d",&id);
        scanf("%lld/%lld",&p,&q);
        //printf("p=%lld q=%lld\n",p,q);
        printf("%d ",id);
        solve(p,q);
    }
}
