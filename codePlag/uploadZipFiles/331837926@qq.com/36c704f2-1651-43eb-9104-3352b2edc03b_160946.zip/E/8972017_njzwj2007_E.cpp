#include <bits/stdc++.h>
using namespace std;
typedef long long ll;



int main() {
    int T, icase;
    ll p,q,a,b;
    scanf("%d", &T);
    while (T--) {
        scanf("%d", &icase);
        scanf("%lld%*c%lld", &p, &q);
        printf("%d ", icase);
        if (q==1) {
            printf("1/%lld\n", p+1);
            continue;
        }
        if (p<q) {
            b=q-p;a=q-b;
            printf("%lld/%lld\n", a+b, b);
        }else {
            int cnt=0;
            a=p-q;b=p-a;
            while (1) {
                p=a;q=b;
                ++cnt;
                if (p<q) {
                    b=q-p;a=q-b;
                    break;
                }
                a=p-q;b=p-a;
            }
            p=a+b;q=b;
            while (cnt--){
                a=p;b=q;
                p=a;q=a+b;
            }
            printf("%lld/%lld\n", p,q);
        }
    }
    return 0;
}
//5 1 1/1 2 1/3 3 5/2 4 2178309/1346269 5 1/10000000
