#include <iostream>
#include <cstdio>
#include <cmath>
#include <string.h>
#include <string>
using namespace std;
bool f[10005]={false};
bool state[330];
int main()
{
    int p;
    scanf("%d",&p);
    for (int C=1;C<=p;C++)
    {
        int k,a,b;
        scanf("%d %d/%d",&k,&a,&b);
        if (a==1&&b==1)
        {
            printf("%d %d/%d\n",k,1,2);
            continue;
        }
        if (a<b)
        {
            printf("%d %d/%d\n",k,b,b-a);
            continue;
        }
        if (b==1)
        {
            printf("%d %d/%d\n",k,1,b+a);
            continue;
        }
        int t=a/b;
        a=a%b;
        int tmp=b-a;
        a=b;b=tmp;
        b=b+t*a;
        printf("%d %d/%d\n",k,a,b);
    }
}
