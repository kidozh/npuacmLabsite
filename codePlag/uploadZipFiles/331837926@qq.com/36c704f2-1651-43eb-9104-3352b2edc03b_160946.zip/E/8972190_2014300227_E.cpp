#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
LL p,q;
int step=0;
char s[100];
void dfs()
{
    if(p>q)
    {
        p=p-q;
        step++;
        dfs();
    }
    return ;
}
void init()
{
    int len=strlen(s);
    p=0;q=0;
    int pos;
    for(int i=0;i<len;i++)
    {
        if(s[i]=='/'){pos=i+1;break;}
        p=p*10+s[i]-'0';
    }
    for(int j=pos;j<len;j++)
    {
       // cout<<q<<" "<<s[j]<<" "<<s[j]-'O'<<endl;
        q=q*10+(s[j]-'0');
    }

}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        int k;char m;
        scanf("%d %s",&k,s);
        init();
        //cout<<p<<" ** "<<q<<endl;
        printf("%d ",k);
        if(q==1)printf("1/%lld\n",p+q);
        else
        {
            if(p<q)printf("%lld/%lld\n",q,q-p );
            else
            {
                step=0;
                dfs();
                q=q-p;
                LL tep;
                p=p+q;
                while(step--)
                {
                    q=q+p;
                }
                printf("%lld/%lld\n",p,q);
            }
        }
    }
    return 0;
}
