#include <iostream>
#include <stdio.h>
using namespace std ;
int main()
{
    int n , k ;
    int fenzi , fenmu;
    cin >>n ;
    while(n--)
    {
        cin >>k ;
        scanf("%d/%d" , &fenzi , &fenmu) ;
        printf("%d ",k);
        if(fenmu == 1)
            printf("%d/%d\n" , 1,fenzi+fenmu);
        else if(fenzi < fenmu)
            printf("%d/%d\n" , fenmu,fenmu-fenzi);
        else
        {
            int A = fenzi-fenmu;
            int B = fenmu ;
            int step  = 1 ;
            while(A>B)
            {
                A = A-B;
                step ++ ;
            }
            int t ;
            t = A ;
            A = B ;
            B = t ;
            B = A-t;
            while(step --)
            {
                B = A+B;
            }
            printf("%d/%d\n" , A,B) ;
        }
    }
    return 0 ;
}
