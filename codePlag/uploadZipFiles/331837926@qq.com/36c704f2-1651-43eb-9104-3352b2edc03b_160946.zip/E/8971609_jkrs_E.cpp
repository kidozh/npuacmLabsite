/*jkrs*/
#include <bits/stdc++.h>
#define ff first
#define ss second
#define clr(_x,_y) memset(_x,_y,sizeof (_x))
#define pt(y) push_back(y)
#define mk(x,y) make_pair(x,y)
#define pof() pop_front()
#define pob() pop_back()
#define puf() push_front()
#define ls p << 1
#define rs p << 1 | 1
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int inf = 0x3f3f3f3f;
const ll linf = 1e18;
const double pi = acos(-1.0);
const int MAXN = 1e4 + 10;
const int MAXM = 1e5 + 10;
const double eps = 1e-8;



int main()
{
//    freopen("in.txt","r",stdin);
    int t;
    scanf("%d",&t);
    while (t --)
    {
        int k;
        int p,q;
        char ch;
        scanf("%d%d%c%d",&k,&p,&ch,&q);
//        printf("p = %d q = %d\n",p,q);
        if (p == 1 && q == 1)
        {
//            puts("asd");
            printf("%d 1/2\n",k);
        }
        else if (p < q)
            printf("%d %d/%d\n",k,q,q - p);
        else
        {
            int sum = p / q;
            p -= sum * q;
            if (p < q)
            {
                q -= p;
                p += q;
            }
            while (sum --)
                q += p;
            printf("%d %d/%d\n",k,p,q);
        }
    }
    return 0;
}
