#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
using namespace std;

typedef long long LL;

int main ()
{
    LL P;
    cin>>P;
    while(P--)
    {
        LL K,a,b;
        scanf("%lld %lld/%lld",&K,&a,&b);
        if(b==1)
        {
            printf("%lld 1/%lld\n",K,a+1);
        }
        else if(a<b)
        {
            printf("%lld %lld/%lld\n",K,b,b-a);
        }
        else
        {
            LL cn=0;
            LL t;
            while(a>b)
            {
                a-=b;
                cn++;
            }
            t=b;
            b=b-a;
            a=t;
            while(cn--)
            {
                b=b+a;
            }
            printf("%lld %lld/%lld\n",K,a,b);
        }
    }
    return 0;
}
