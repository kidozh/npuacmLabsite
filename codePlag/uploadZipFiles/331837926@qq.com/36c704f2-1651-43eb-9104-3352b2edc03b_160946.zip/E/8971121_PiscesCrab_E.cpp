//By Sean Chen
#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;
int p,q,Case,T;
char temp;
int main()
{
    scanf("%d",&T);
    for (int i=0;i<T;i++)
    {
        scanf("%d%d%c%d",&Case,&p,&temp,&q);
        if (p<q)
        {
            printf("%d %d/%d\n",Case,q,q-p);
            continue;
        }
        if (q==1)
        {
            printf("%d %d/%d\n",Case,1,p+1);
            continue;
        }
        int cnt=0;
        while (p>q)
        {
            cnt++;
            p-=q;
        }
        q=q-p;
        p=p+q;
        for (int i=1;i<=cnt;i++)
            q+=p;
        printf("%d %d/%d\n",Case,p,q);
    }
    return 0;
}