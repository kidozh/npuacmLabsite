#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
    int T,t;
    long long p,q,x,y;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%lld/%lld",&t,&x,&y);
        printf("%d ",t);
        if(x==1&&y==1)
            printf("1/2\n");
        else{
            if(x<y){
                p=x;
                q=y-x;
                printf("%lld/%lld\n",p+q,q);
            }//left
            else{
                q=y;
                p=x-y;
                if(q==1)
                    printf("%lld/%lld\n",q,x+q);
                else
                    printf("%lld/%lld\n",y,y-x%y+y*(x/y));
            }
        }
    }
    return 0;
}