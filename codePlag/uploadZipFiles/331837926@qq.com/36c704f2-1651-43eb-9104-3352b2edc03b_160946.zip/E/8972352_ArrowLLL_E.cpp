#include <bits/stdc++.h>

using namespace std;

void dfs(int &a, int &b)
{
    int t = a / b;
    a %= b;
    b -= a;
    a += b;
    b += t * a;
}

int main()
{
    int T;
    //freopen("data.in", "r", stdin);
    scanf("%d", &T);
    while(T--) {
        int t, a, b;
        scanf("%d %d/%d", &t, &a, &b);
        if(a == b) b += a;
        else dfs(a, b);
        printf("%d %d/%d\n", t, a, b);
    }
    return 0;
}
