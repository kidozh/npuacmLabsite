#include <iostream>
#include <cstdio>
using namespace std;
int num;
void solve(int a,int b,int n)
{
	    if(a<b)
		{

			int s=a;
			a=b;
			b=b-s;
			while(n--)
				b=b+a;
			printf("%d %d/%d\n",num,a,b);
			return;
		}
		if(a>b)
		{
			solve(a-b,b,n+1);
			//??

		}
		return;
}
int main()
{
	int m;

	scanf("%d",&m);
	while(m--)
	{
		int a,b;
		scanf("%d%d/%d",&num,&a,&b);
		if(b==1)
		{
			printf("%d %d/%d\n",num,b,a+b);
			continue;
		}
		if(a<b)
		{

			printf("%d %d/%d\n",num,b,b-a);
			continue;
		}
		if(a>b)
		solve(a,b,0);

		//printf("%d%d%d",num,b,a+b);
	}
	return 0;
}
