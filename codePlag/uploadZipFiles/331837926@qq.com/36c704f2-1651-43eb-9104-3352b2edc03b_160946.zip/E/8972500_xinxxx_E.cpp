#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
using namespace std;
int gcd(int a,int b)
{
    return b==0?a:gcd(b,a%b);
}

int main()
{
    int t,kase,p,q,ans1,ans2;
    scanf("%d",&t);
    char c;
    while(t--)
    {
        scanf("%d",&kase);
        scanf("%d%c%d",&p,&c,&q);
        if(p==1 && q==1) {ans1=1;ans2=2;}
        else if(q==1)
        {
            ans2=p+1;
            ans1=1;
        }
        else if(p<q)
        {
            ans1=q;
            ans2=q-p;
        }
        else
        {
            int cnt1=0,cnt2=0;
            while(p>q)
            {
                p-=q;
                cnt1++;
            }
            q-=p;
            p+=q;
            while(cnt1--) q+=p;
            ans1=p;
            ans2=q;
        }
        int t=gcd(ans1,ans2);
        printf("%d %d/%d\n",kase,ans1/t,ans2/t);
    }
    return 0;
}
