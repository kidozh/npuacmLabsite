#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;
int fenzi,fenmu;
int main(){
    int T,nc;
    scanf("%d",&T);
    while(T--){
        scanf("%d ",&nc);
        printf("%d ",nc);
        char ch;
        scanf("%d%c%d",&fenzi,&ch,&fenmu);
        // cout<<fenzi<<" "<<fenmu<<endl;
        if(fenzi == 1 && fenmu == 1) {
            puts("1/2");
        }
        else if(fenmu == 1){
            printf("1/%d\n",fenzi+1);
        }
        else if(fenzi > fenmu){
            int dep = 0;
            while(fenzi > fenmu)
            {
                dep ++;
                fenzi = fenzi - fenmu;
            }
            int ffz,ffm;
            ffz = fenmu ;
            ffm = fenmu - fenzi;
            while(dep){
                ffm += ffz;
                dep --;
            }
            printf("%d/%d\n",ffz,ffm);
        }
        else{
            printf("%d/%d\n",fenmu,fenmu - fenzi );
        }
    }
    return 0;
}
/*

5
1 1/1
2 1/3
3 5/2
4 2178309/1346269
5 1/10000000
*/