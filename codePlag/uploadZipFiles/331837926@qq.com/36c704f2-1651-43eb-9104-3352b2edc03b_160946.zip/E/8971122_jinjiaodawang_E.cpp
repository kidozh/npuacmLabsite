#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define debug(a) cout<<a<<endl
#define clr(a) memset(a,0,sizeof(a))
#define clrne(a) memset(a,-1,sizeof(a))
#define clrinf(a) memset(a,0x3f,sizeof(a))
#define clrneinf(a) memset(a,0xc0,sizeof(a))
#define pb(a) push_back(a)
#define mp(a,b) make_pair(a,b)
#define mod 1000000007
#define eps 1e-9
#define inf 0x7fffffff
#define pr pair<int,int>
pr fa (pr a)
{
    int p = a.first;
    int q = a.second;
    if (p<q) return mp(p,q-p);
    else return mp(p-q,q);
}
pr solve(pr a)
{
    int p = a.first;
    int q = a.second;
    if (p==1&&q==1) return mp(1,2);
    else if (p==1) return mp(q,q-1);
    else if (q==1) return mp(1,p+1);
    else
    {
        if (p<q)
        {
            int fap = p;
            int faq = q-p;
            return mp(fap+faq,faq);
        }
        else
        {
            pr temp = mp(p,q);
            int cnt = 0;
            while (temp.first>temp.second)
            {
                cnt++;
                temp = fa(temp);
            }
            if (temp!=mp(1,1)) temp = solve(temp);
            while (cnt--)
            {
                pr tt;
                tt.first = temp.first;
                tt.second = temp.first + temp.second;
                temp = tt;
            }
            return temp;
        }
    }
}
int main()
{
//  freopen("in.txt","r",stdin);
//  freopen("out.txt","w",stdout);
    int T;
    scanf("%d",&T);
    while (T--)
    {
        int temp;
        scanf("%d",&temp);
        int p,q;
        scanf("%d %*c %d",&p,&q);
        pr aa = solve(mp(p,q));
        cout<<temp<<' ';
        cout<<aa.first<<'/'<<aa.second<<endl;
    }
    return 0;
}
