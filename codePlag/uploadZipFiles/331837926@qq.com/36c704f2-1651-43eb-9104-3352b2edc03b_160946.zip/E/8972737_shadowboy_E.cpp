#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;
int main()
{
    int n;
    scanf("%d",&n);
    for(int cases=1;cases<=n;cases++){
        int tmp;
        int  a=0,b=0;
        scanf("%d %d/%d",&tmp,&a,&b);
        if(b==1){
            cout<<tmp<<" "<<1<<"/"<<a+b<<endl;
        }else if(a<b){
            cout<<tmp<<" "<<b<<"/"<<b-a<<endl;
        }else {
            int  ceng=a/b;
            int ra=a%b,rb=b;
            rb-=ra;
            ra=ra+rb;
            rb=rb+ceng*ra;
            cout<<tmp<<" "<<ra<<"/"<<rb<<endl;
        }
    }
    return 0;
}

