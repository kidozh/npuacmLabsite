// e a rational.cpp : ??????????????
//
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int p,q,cnt;
void cal()
{
    cnt=0;

    while(p>q)
    {
        p=p-q;
        cnt++;

    }

    int i,j;
    i=p;
    j=q;
    p=j;
    q=j-i;

    while(cnt>0)
    {
        cnt--;
        q=p+q;
    }
}
int main()
{
    //cout << "Hello world!" << endl;
    int t,i=1;

    scanf("%d",&t);

    while(i<=t)
    {
        scanf("%d %d/%d",&i,&p,&q);
		if(q==1)
		{
		    printf("%d %d/%d\n",i,q,q+p);
		}
		else if(p<q){
            printf("%d %d/%d\n",i,q,q-p);
		}
		else if(p>q)
		{
		    cal();
		    printf("%d %d/%d\n",i,p,q);
		}

        i++;
    }
    return 0;
}



