#include <cstdio>
#include <cstring>

using namespace std;
int main()
{
    int p,k,x,y;
    while(~scanf("%d",&p))
    {
        while(p--)
        {
            scanf("%d%d%d",&k,&x,&y);
            printf("%d ",k);
            if(x<y)
            {
                printf("2 %d %d\n",x,y);
                continue;
            }
            if(y<4)
            {
                printf("NO PATH\n");
                continue;
            }
            printf("6 1 2 3 %d %d %d\n",x+1-(y-4),x+2,x+3);
        }
    }
    return 0;
}
