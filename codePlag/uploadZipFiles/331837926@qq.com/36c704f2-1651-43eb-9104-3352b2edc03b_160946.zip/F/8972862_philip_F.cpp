#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;

int main()
{
    int T;
    scanf("%d", &T);
    while(T--)
    {
        int n;
        scanf("%d", &n);
        int x, y;
        scanf("%d %d", &x, &y);
        if(x < y)
            printf("%d 2 %d %d\n", n, x, y);
        else if(y >= 4)
        {
            printf("%d 6 1 2 3 %d %d %d\n",n ,x+5-y ,x+2 ,x+3);
        }

        else
            printf("%d NO PATH\n", n);
    }
}
