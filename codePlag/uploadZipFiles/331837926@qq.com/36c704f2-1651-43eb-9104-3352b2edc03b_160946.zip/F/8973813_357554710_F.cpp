#include<cstdio>
using namespace std;

void solve(int x,int y)
{
    if(x==y)
    {
        printf("NO PATH\n");
        return;
    }
    if(x<y)
    {
        printf("2 %d %d\n",x,y);
        return;
    }
    else
    {
        if(y<3)
        {
            printf("NO PATH\n");
            return;
        }
        int a1=1,d1=1,d2=1;
        int d3=x-y+2;
        int d4=x-a1-d3;
        int d5=y-a1-d1-d4;
        printf("6 %d %d %d %d %d %d\n",a1,a1+d1,a1+d1+d2,a1+d1+d2+d3,a1+d1+d2+d3+d4,a1+d1+d2+d3+d4+d5);
    }
}

int main()
{
    int T,id,x,y;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d%d",&id,&x,&y);
        printf("%d ",id);
        solve(x,y);
    }
}
