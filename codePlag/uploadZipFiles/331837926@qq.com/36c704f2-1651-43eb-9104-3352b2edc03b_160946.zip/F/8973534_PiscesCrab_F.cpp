//By Sean Chen
#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;
int T,Case,x,y;
int main()
{
    scanf("%d",&T);
    for (int i=0;i<T;i++)
    {
        scanf("%d%d%d",&Case,&x,&y);
        if (y>x)
            printf("%d %d %d %d\n",Case,2,x,y);
        else if (x>=3 && y>=4)
            printf("%d %d %d %d %d %d %d %d\n",Case,6,1,2,3,x+5-y,x+2,x+3);
        else
            printf("%d NO PATH\n",Case);
    }
    return 0;
}
