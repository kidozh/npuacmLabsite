#include <bits/stdc++.h>
using namespace std;

int main()
{
	int T, cas, x, y;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d%d%d", &cas, &x, &y);
		printf("%d ", cas);
		if (x == 1 && y == 1) { puts("NO PATH"); continue; }
		if (x < y) { printf("2 %d %d\n", x, y); continue; }
		if (y < 4) /* ??? */ { puts("NO PATH"); continue; }
		int a5 = x + 2, a6 = x + 3;
		int a4 = a6 - y + 2;
		printf("6 1 2 3 %d %d %d\n", a4, a5, a6);
	}
	return 0;
}
