#include <iostream>
#include <cstdio>
#include <cmath>
#include <string.h>
#include <string>
using namespace std;
int dp[2005][505]={0};
int main()
{
    int p;
    cin>>p;
    for(int C=1;C<=p;C++)
    {
        int k;
        cin>>k;
        int x,y;
        cin>>x>>y;
        cout<<k<<" ";
        if (y==0&&x>0)
        {
            cout<<1<<" "<<x<<endl;
            continue;
        }
        if (x==0||y==0)
        {
            cout<<"NO PATH"<<endl;
            continue;
        }
        if (x>0&&y>0)
        {
            if (x<y)
            {
                cout<<"2 "<<x<<" "<<y<<endl;
                continue;
            }
            else
            {
                int t=x+3-y+2;
                if (t>3&&t<x+3-1)
                {
                    cout<<"6 "<<"1 2 3 "<<t<<" "<<x+3-1<<" "<<t-2+y<<endl;
                    continue;
                }
                else
                {
                    cout<<"NO PATH"<<endl;
                    continue;
                }
            }
        }
        if (x<0&&y>0)
        {
            if (1-x>y)
            {
                cout<<"3 1 "<<y<<" "<<1-x<<endl;
                continue;
            }
            else
            {
                int t=x+y+5;
                if (t>4&&t<y+2)
                {
                    cout<<"7 1 2 3 4 "<<t<<" "<<y+2<<" "<<t-2-x<<endl;
                    continue;
                }
                else
                {
                    cout<<"NO PATH"<<endl;
                    continue;
                }
            }
        }
        if (x<0&&y<0)
        {
            if (2-y>1-x)
            {
                cout<<"4 1 2 "<<1-x<<" "<<2-y<<endl;
                continue;
            }
            else
            {
                int t=6+y-x;
                if (t>5&&t<3-x)
                {
                    cout<<"8 1 2 3 4 5 "<<t<<" "<<3-x<<" "<<t-2-y<<endl;
                    continue;
                }
                else
                {
                    cout<<"NO PATH"<<endl;
                    continue;
                }
            }
        }
        if (x>0&&y<0)
        {
            if (2-y<2+x)
            {
                cout<<"5 1 2 3 "<<2-y<<" "<<2+x<<endl;
                continue;
            }
            else
            {
                int t=7-y-x;
                if (t>6&&t<4-y)
                {
                    cout<<"9 1 2 3 4 5 6 "<<t<<" "<<4-y<<" "<<t-3+x<<endl;
                    continue;
                }
                else
                {
                    cout<<"NO PATH"<<endl;
                    continue;
                }
            }
        }
    }
}
