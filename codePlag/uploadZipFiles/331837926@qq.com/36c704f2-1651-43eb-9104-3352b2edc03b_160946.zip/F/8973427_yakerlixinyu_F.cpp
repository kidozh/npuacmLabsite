#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int m;

	scanf("%d",&m);
	while(m--)
	{
		int num,a,b;
		scanf("%d%d%d",&num,&a,&b);
		if(a>=b&&b<=3)
			{
				printf("%d NO PATH\n",num);
				continue;
			}
		if(a<b)
		{
			printf("%d 2 %d %d\n",num,a,b);
		}
		else
		{
			int t1;
			t1=a+2;

			if(t1-(b-2)+1>3)
			{
				printf("%d 6 1 2 3 %d %d %d\n",num,t1-(b-2)+1,t1,t1+1);
			}
			else printf("%d 6 1 2 3 4 %d %d\n",num,t1,4+b-2);

		}


	}
	return 0;
}
