#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
using namespace std;
int x,y;

int main()
{
    int t,kase;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d%d",&kase,&x,&y);
        if(x<=2 || y<=2) printf("%d NO PATH\n",kase);
        else if(x<y) printf("%d 2 %d %d\n",kase,x,y);
        else if(y==3) printf("%d NO PATH\n",kase);
        else
        {
            int k=x+3-y;
            printf("%d 6 1 2 3 %d %d %d\n",kase,2+k,x+2,y+k);
        }
    }
    return 0;
}
