#include<cstdio>
#include<iostream>
using namespace std;

int main ()
{
    int P;
    cin>>P;
    while(P--)
    {
        int K,x,y;
        scanf("%d%d%d",&K,&x,&y);
        if(x==0||y==0)
        {
            if(y==0&&x>0)
            {
                printf("%d %d %d\n",K,1,x);
            }
            else
            {
                printf("%d NO PATH\n",K);
            }
        }
        else
        {
            if(x>0&&y>0)
            {
                if(y>x)
                {
                    printf("%d %d %d %d\n",K,2,x,y);
                }
                else
                {
                    if(x<3||y<3)
                    {
                        printf("%d NO PATH\n",K);
                    }
                    else
                    {
                        printf("%d %d %d %d %d %d %d %d\n",K,6,1,2,3,5+x-y,x+2,3+x);
                    }
                }
            }
            else if(x<0&&y>0)
            {
                if(x==-1)
                {
                    printf("%d NO PATH\n",K);
                }
                else
                {
                    printf("%d %d %d %d %d\n",K,3,y-1,y,y-x-1);
                }
            }
            else if(x<0&&y<0)
            {
                if(x==-1||y==-1)
                {
                    printf("%d NO PATH\n",K);
                }
                else
                {
                    printf("%d %d %d %d %d %d\n",K,4,1,-x,1-x,-x-y);
                }
            }
            else if(x>0&&y<0)
            {
                if(x<3||y==-1)
                {
                    printf("%d NO PATH\n",K);
                }
                else
                {
                    printf("%d %d %d %d %d %d %d\n",K,5,1,2,4-x-y,2-y,3-y);
                }
            }
        }
    }
    return 0;
}
