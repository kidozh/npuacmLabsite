#include <bits/stdc++.h>
using namespace std;
int seq[50];

int main() {
    int T, icase, x, y;
    scanf("%d", &T);
    while (T--) {
        scanf("%d%d%d", &icase, &x, &y);
        printf("%d ", icase);
        if (x<3&&y<=x||y<4) {
            puts("NO PATH");
            continue;
        }
        if (y>x) {
            printf("2 %d %d\n", x, y);
        }else {
            int ans=0x3f3f3f3f, len=0;
            for (int i=1;i<=5;++i) {
                int a, b, c;
                b=x+2*i;c=b+1;
                a=c-(y-2*i);
                if (a<=i*4-1) {
                    a=i*4;
                    c=a+y-2*i;
                }
                int tmp=(4*i-1)*2*i+a+b+c;
                if (tmp<ans) {
                    ans=tmp;
                    len=4*i+2;
                    for (int j=1;j<4*i;++j) seq[j]=j;
                    seq[4*i]=a; seq[4*i+1]=b; seq[4*i+2]=c;
                }
                //for (int j=1;j<4*i;++j) printf("%d ", j);
                //printf("%d %d %d, %d\n", a, b, c, ans);
            }
            printf("%d", len);
            for (int i=1;i<=len;++i) printf(" %d", seq[i]);
                puts("");   
        }
    }
    return 0;
}
