#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;
int main()
{
    int n;
    scanf("%d",&n);
    for(int cases=1;cases<=n;cases++){
        int tmp;
        cin>>tmp;
        int x,y;
        cin>>x>>y;
        if(x<y)
            cout<<tmp<<" "<<2<<" "<<x<<" "<<y<<endl;
        else if(x<=1||y<=2)
            cout<<tmp<<" "<<"NO PATH"<<endl;
        else {
            int l=x-y+2+1,r = x-1;
            int a=max(2,x+2-y+1);
            cout<<tmp<<" "<<6<<" 1 2 3 "<<a+2<<" "<<x+2<<" "<<y+a<<endl;
        }
    }
    return 0;
}

