#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;
int ca,p;
int a[20];
void init(){
    scanf("%d",&p);
    for(int i = 0; i < 12 ; i++){
        scanf("%d",&a[i]);
    }
}

void sov(){
    int ans = 0;
    for(int i = 1; i <= 10 ; i++){
        for(int j = 1; j <= 10-i+1; j++){
            int minn = (1<<30);
            for(int k = j ; k <= i+j-1 ; k++){
                minn = min(minn,a[k]);
                //cout <<"minbn =  " <<minn<<endl;
            }
            if(minn > a[j-1] && minn > a[j+i])
                ans++;
        }
    }
    printf("%d %d\n",ca,ans);
}

int main(){
    int T;
    scanf("%d",&T);
    for(ca = 1; ca <= T; ca++){
        init();
        sov();
    }
}

