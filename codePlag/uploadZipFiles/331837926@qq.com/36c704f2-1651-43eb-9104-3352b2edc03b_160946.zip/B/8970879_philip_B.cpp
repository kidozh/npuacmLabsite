#include<cstdio>
#include<algorithm>
#include<iostream>

using namespace std;

int num[14];
bool check(int be, int en)
{
    int k = num[be];
    for(int i = be + 1; i <= en; i++)
    {
        if(k > num[i])
            k = num[i];
    }

    if(k > num[be-1] && k > num[en+1])
        return true;
    return false;
}
int main()
{
    int T;
    scanf("%d", &T);
    while(T--)
    {   num[0] = num[13] = 0;
        int n;
        scanf("%d", &n);
        for(int i = 1; i < 13;i++)
        {
            scanf("%d",&num[i]);
        }
        int ans = 0;
        for(int i=1;i<13;i++)
        {
            for(int j=i;j<12;j++)
            {
                if(check(i,j))
                    ans++;
            }
        }
        printf("%d %d\n",n, ans);
    }
    return 0;
}
