#include <iostream>
#include<cstdio>
#include<queue>
#include<map>
#include<stdlib.h>
#include<algorithm>
#define ll long long
using namespace std;
int T,n;
ll a[20];
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);
        for(int i=0;i<12;i++)
        {
            scanf("%d",&a[i]);
        }
        int cnt=0;
        for(int i=1;i<11;i++)
        {
            for(int j=1;j<=i;j++)
            {
                if(a[j]>a[j-1]&&a[i]>a[i+1])
                {
                    int flag=0;
                    for(int k=j;k<=i;k++)
                    {
                        if(a[k]<=a[j-1]||a[k]<=a[i+1])
                        {
                            flag=1;break;
                        }

                    }
                    //printf("%d %d\n",j,i);
                    if(!flag)cnt++;
                }
            }
        }
        printf("%d %d\n",n,cnt);
    }
    return 0;
}
