#include<bits/stdc++.h>

#define inf 0x3f3f3f3f

const int maxn=100;

using namespace std;

int t;

int a[maxn+10];

int main()
{
       scanf("%d",&t);
       while(t--){
                int k;
                scanf("%d",&k);
                memset(a, 0 , sizeof(a));
                for(int i = 1; i <= 12; ++i){
                        scanf("%d",&a[i]);
                }

                int ans = 0;
                for(int i = 1; i <= 12; ++i){
                        for(int j = i; j <= 12; ++j){

                                int imin = 0x7f7f7f7f;
                                for(int k = i; k <= j; ++k){
                                        imin = min(a[k], imin);
                                }

                                if(imin > a[i-1] && imin > a[j+1]){
                                        ++ans;
                                }
                        }
                }
                printf("%d %d\n",k,ans);
       }
    return 0;
}
/*
4
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 0
*/
