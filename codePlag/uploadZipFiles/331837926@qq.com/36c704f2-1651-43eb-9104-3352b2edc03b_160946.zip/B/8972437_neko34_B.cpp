#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>
using namespace std;
int n;
const int MAXN = 15;
int a[MAXN];
const int INF = 0x3f3f3f3f;
int main(){
    int T,nc;
    n = 12;
    scanf("%d",&T);
    while(T--){
        scanf("%d",&nc);
        printf("%d ",nc);
        for(int i=1;i<=n;i++){
            scanf("%d",&a[i]);
        }
        int ans = 0;
        for(int i=1;i<=n;i++){
            for(int j=i+2;j<=n;j++){
                int minn = INF;
                for(int k=i+1;k<=j-1;k++){
                    minn = min(minn,a[k]);
                }
                if(minn > a[i] && minn > a[j]) ans++;
            }
        }
        printf("%d\n",ans);
    }


    return 0;
}