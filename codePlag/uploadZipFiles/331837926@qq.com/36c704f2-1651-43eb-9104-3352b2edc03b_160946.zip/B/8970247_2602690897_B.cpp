#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
int main()
{
    //freopen("a.txt","r",stdin);
    int p,k,t,arr[12];
    cin>>p;
    for(int i=1;i<=p;i++)
    {
        cin>>t;
        for(int j=0;j<12;j++)
        {
            cin>>arr[j];
        }
        int ans=0;
        for(int k1=1;k1<11;k1++)
        {
            for(int k2=k1;k2<11;k2++)
            {
                bool flag=true;
                int maxmin=max(arr[k1-1],arr[k2+1]);
                for(int m=k1;m<=k2;m++)
                {
                    if(arr[m]<=maxmin)
                    {
                        flag=false;
                        break;
                    }
                }
                ans+=flag;
            }
        }
        cout<<i<<" "<<ans<<endl;
    }
    return 0;
}