#include <iostream>

using namespace std;
int a[100];

int main()
{
    int p;
    cin>>p;
    for(int C=1;C<=p;C++)
    {
        int s=0;
        int k;
        cin>>k;
        for(int j=1;j<=12;j++)
            cin>>a[j];
        for(int i=2;i<=11;i++)
            for(int j=i;j<=11;j++)
        {
            bool flag=true;
            for(int l=i;l<=j;l++)
            if (a[l]<=a[i-1]||a[l]<=a[j+1]) {flag=false;break;}
            if (flag) s++;
        }
        cout<<k<<' '<<s<<endl;
    }
    return 0;
}
