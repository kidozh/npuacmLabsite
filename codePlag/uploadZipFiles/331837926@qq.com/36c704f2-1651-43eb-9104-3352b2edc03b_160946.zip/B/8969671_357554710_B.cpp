#include<cstdio>
#include<algorithm>
#define maxn 20
#define inf 0x3f3f3f3f
using namespace std;

int a[maxn+5];
int minnum[maxn+5][maxn+5];

int getminnum(int i,int j)
{
    int ans=inf;
    for(int x=i;x<=j;x++)
    {
        ans=min(ans,a[x]);
    }
    return ans;
}

int solve()
{
    for(int i=1;i<=12;i++)
    {
        for(int j=i;j<=12;j++)
        {
            minnum[i][j]=getminnum(i,j);
        }
    }

    int ans=0;
    for(int i=2;i<=11;i++)
    {
        for(int j=i;j<=11;j++)
        {
            if(minnum[i][j]>a[i-1] && minnum[i][j]>a[j+1]) ans++;
        }
    }
    return ans;
}

int main()
{
    int T;
    scanf("%d",&T);
    for(int kase=1;kase<=T;kase++)
    {
        int id;
        scanf("%d",&id);
        for(int i=1;i<=12;i++)
        {
            scanf("%d",&a[i]);
        }
        printf("%d %d\n",id,solve());
    }
    return 0;
}
