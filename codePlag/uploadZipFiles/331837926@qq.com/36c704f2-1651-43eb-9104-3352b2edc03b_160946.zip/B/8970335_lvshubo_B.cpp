#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int p,t,ans,a[20],i,j,mi;
    while(scanf("%d",&p)!=EOF)
    {
        while(p--){
            scanf("%d",&t);
            for(i=0;i<12;i++)
                scanf("%d",&a[i]);
            for(i=0,ans=0;i<11;i++){
                if(a[i]<a[i+1]){
                    for(j=i+1,mi=a[j];j<11&&a[j]>a[i];j++){
                        if(a[j]<mi)
                            mi=a[j];
                        if(mi>a[j+1])
                            ans++;
                    }
                }
            }
            printf("%d %d\n",t,ans);
        }
    }
    return 0;
}
