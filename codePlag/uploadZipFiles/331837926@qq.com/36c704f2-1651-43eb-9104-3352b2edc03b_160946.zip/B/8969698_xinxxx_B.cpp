#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
using namespace std;
int a[15];

int main()
{
    int t,i,cnt=0,j,k,kase;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&kase);
        cnt=0;
        for(i=0;i<12;i++) scanf("%d",&a[i]);
        for(i=1;i<11;i++)
        {
            for(j=i;j<11;j++)
            {
                int l=a[i-1],r=a[j+1];
                bool f=true;
                for(k=i;k<=j;k++)
                {
                    if(a[k]<=l || a[k]<=r)
                    {
                        f=false;
                        break;
                    }
                }
                if(f) cnt++;
            }
        }
        printf("%d %d\n",kase,cnt);
    }
    return 0;
}
