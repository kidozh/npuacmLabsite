#include<iostream>

using namespace std;

int main ()
{
    int minn[13][13];
    int a[12];
    int i,j,l;
    int n,k;
    cin>>n;
    while(n--)
    {
        cin>>k;
        int sum=0;
        for(i=1;i<=12;i++)
            cin>>a[i];
        for(i=2;i<=11;i++)
        {
            for(j=i;j<=11;j++)
            {
                int mn=999999999;
                for(l=i;l<=j;l++)
                {
                    if(a[l]<mn)
                        mn=a[l];
                }
                minn[i][j]=mn;
            }
        }
        for(i=2;i<=11;i++)
        {
            for(j=i;j<=11;j++)
            {
                if(minn[i][j]>a[i-1]&&minn[i][j]>a[j+1])
                    sum++;
            }
        }
        cout<<k<<' '<<sum<<endl;
    }
}
