/*jkrs*/
#include <bits/stdc++.h>
#define ff first
#define ss second
#define clr(_x,_y) memset(_x,_y,sizeof (_x))
#define pt(y) push_back(y)
#define mk(x,y) make_pair(x,y)
#define pof() pop_front()
#define pob() pop_back()
#define puf() push_front()
#define ls p << 1
#define rs p << 1 | 1
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int inf = 0x3f3f3f3f;
const ll linf = 1e18;
const double pi = acos(-1.0);
const int MAXN = 1e5 + 10;
const int MAXM = 1e5 + 10;
const double eps = 1e-8;

int a[25];

int main()
{
    int t;
    scanf("%d",&t);
    while (t --)
    {
        int k;
        scanf("%d",&k);
        for (int i = 0 ;i < 12; ++ i)
            scanf("%d",&a[i]);
        int sum = 0;
        for (int i = 1;i < 11; ++ i)
        {
            for (int j = i;j < 11; ++ j)
            {
                bool flag = 1;
                for (int k = i;k <= j; ++ k)
                {
                    if (a[k] <= a[i - 1] || a[k] <= a[j + 1])
                    {
                        flag = 0;
                        break;
                    }
                }
                sum += flag;
            }
        }
        printf("%d %d\n",k,sum);
    }
    return 0;
}
