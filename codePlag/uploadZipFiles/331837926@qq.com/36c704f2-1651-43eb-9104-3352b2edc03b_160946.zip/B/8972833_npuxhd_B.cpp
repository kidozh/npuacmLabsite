#include <iostream>
#include<algorithm>
#include<stdio.h>
#include<string.h>
using namespace std;

int  num[16];
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        int cnt;
        scanf("%d",&cnt);

        for(int i=1;i<=12;i++)
        {
            scanf("%d",&num[i]);
        }

        int ans=0;
        for(int i=2;i<=11;i++)
        {
            for(int j=i;j<=11;j++)
            {
                bool ssc=1;
                for(int k=i;k<=j;k++)
                {
                    if(num[k]<=num[i-1]||num[k]<=num[j+1]) { ssc=0; break;}
                }
                if(ssc) ans++;
            }
        }
        printf("%d %d\n",cnt,ans);
    }
    return 0;
}