#include <iostream>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
using namespace std;
int a[14][14];
int main()
{
    int t = 0;
    scanf("%d",&t);
    for(int i=1;i<=t;i++)
    {
        int z;
        scanf("%d",&z);
        int bc = 1;
        int ans = 0;
        memset(a,0,sizeof(a));
        for(int i=0;i<=11;i++)scanf("%d",&a[i][i]);
        for(int i=0;i<=11;i++){
            if(i == 0){if(a[i][i] > a[i+1][i+1])ans++;}
            else    if(i == 11){if(a[i][i] > a[i-1][i-1])ans++;}
            else{if(a[i][i] > a[i+1][i+1]&&a[i][i] > a[i-1][i-1])ans++;}
        }
        for(bc = 1;bc < 11;bc++)
        {
            for(int i=0;i<11;i++)
            {
                int j = i + bc;
                if(j > 11)break;
                a[i][j] = min(a[i][j-1],a[i+1][j]);
                //if(i == 0&&j == 11)break;
                if(i == 0){if(a[i][j] > a[j+1][j+1])
                    {ans++;}
                }
                else    if(j == 11){
                    if(a[i][j] > a[i-1][i-1])
                    {ans++;}
                }
                else{
                    if(a[i][j] > a[j+1][j+1]&&a[i][j] > a[i-1][i-1])
                        {ans++;}
                }
            }
        }
        printf("%d %d\n",i,ans);
    }
    return 0;
}
