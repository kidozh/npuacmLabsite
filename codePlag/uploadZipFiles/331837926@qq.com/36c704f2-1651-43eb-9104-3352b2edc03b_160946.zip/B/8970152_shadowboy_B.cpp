#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;
int num[30];
int main()
{
    int n;
    scanf("%d",&n);
    for(int cases=1;cases<=n;cases++){
        int tmp;
        int sum=0;
        scanf("%d",&tmp);
        for(int i=1;i<=12;i++){
            scanf("%d",&num[i]);
        }
        for(int i=2;i<=11;i++){
            for(int j=i;j<=11;j++){
                bool flag=true;
                for(int k=i;k<=j;k++){
                    if(num[k]<=num[i-1]||num[k]<=num[j+1])
                        flag=false;
                }
                if(flag)
                    sum++;
            }

        }
        printf("%d %d\n",cases,sum);

    }
    return 0;
}
