#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<set>
#include<list>
#include<algorithm>
#include<functional>
#include<numeric>

#define lson  rt<<1,l,mid
#define rson  rt<<1|1,mid+1,r
#define rep(i,x,y)  for(int i=x;i<y;i++)
#define rrep(i,x,y)  for(int i=x;i>y;i--)
#define mem(a,x)  memset(a,x,sizeof(a))
#define pb  push_back
#define mp  make_pair
#define fir  first
#define sec  second
#define lb  lower_bound
#define ub  upper_bound

using namespace std;
typedef long long ll;
typedef pair<int,int> p;

//printf("hello world\n");

int a[15];

int ncase,k,res;

bool check(int s,int e){
	int goal=max(a[s-1],a[e+1]);
	for(int i=s;i<=e;i++){
		if(goal>=a[i]) return false;
	}
	return true;
}

int main()
{
	scanf("%d",&ncase);
	while(ncase--){
		scanf("%d",&k);
		for(int i=0;i<12;i++){
			scanf("%d",&a[i]);
		}
		res=0;
		for(int i=1;i<11;i++){
			for(int j=i;j<11;j++){
				if(check(i,j)){
					res++;
				}
			}
		}
		printf("%d %d\n",k,res);
	}
	return 0;
}
