#include <cstdio>
#define MAX 2100000000
int a[13],num;
void ser(int l,int r,int f)
{ int i,j;
  while (a[l]==f) l++;
  while (a[r]==f) r--;
  if (l>r) return ;
 for (i=l;i<=r;i++)
      if (a[i]==f) break;
 if (i>r) {
     num++;
     int pi=MAX;
     for (i=l;i<=r;i++)
          if (pi>a[i]) pi=a[i];
	 ser(l,r,pi);
		  }
 else {
      ser(l,i-1,f);
      ser(i+1,r,f);
	  }
}
void work()
{
 int i,j;
 num=0;
 for (i=1;i<=12;i++)
      scanf("%d",&a[i]);
 ser(2,11,0);
 printf("%d\n",num);
 } 
int main()
{
 int p,i,k;
 scanf("%d",&p);
 for (i=1;i<=p;i++){
 	  scanf("%d",&k);
 	  printf("%d ",k);
 	  work();
                   }
}