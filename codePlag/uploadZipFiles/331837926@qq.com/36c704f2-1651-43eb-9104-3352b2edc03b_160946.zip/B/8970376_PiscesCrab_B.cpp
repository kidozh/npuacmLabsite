//By Sean Chen
#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;

int Stack[100];
int T,Case;
int a[15];
int main()
{
    scanf("%d",&T);
    for (int i=0;i<T;i++)
    {
        scanf("%d",&Case);
        memset(Stack,0,sizeof(Stack));
        Stack[0]=0;
        int pre=0,cnt=0;
        a[0]=0;
        a[13]=0;
        for (int i=1;i<=12;i++)
            scanf("%d",&a[i]);
        for (int i=1;i<=12;i++)
            for (int j=i;j<=12;j++)
            {
                int flag=1;
                for (int k=i;k<=j && flag;k++)
                {
                    if (a[k]<=a[i-1] || a[k]<=a[j+1])
                        flag=0;
                }
                if (flag)
                    cnt++;
            }
        printf("%d %d\n",Case,cnt);
    }
    return 0;
}
