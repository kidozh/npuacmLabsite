#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[20];

int main()
{
    int T, icase;
    scanf("%d",&T);
    while (T--) {
        scanf("%d", &icase);
        int ans=0;
        for (int i=0;i<12;++i) scanf("%d",a+i);
        for (int i=1;i<11;++i){
            for (int j=i;j<11;++j){
                bool f=true;
                for (int k=i;k<=j;++k){
                    if (a[k]<=a[i-1]||a[k]<=a[j+1]){
                        f=false;
                        break;
                    }
                }
                if (!f) continue;
                ++ans;
            }
        }
        printf("%d %d\n", icase, ans);
    }
    return 0;
}