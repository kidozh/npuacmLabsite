#include<cstdio>
#include<iostream>
#include<stack>

using namespace std;

int a [15];

int main ()
{
	int cas;
	scanf("%d", &cas);

	while(cas--){
		int no;
		scanf("%d", &no);
		printf("%d ", no);

		for(int i= 0; i< 12; i++)
			scanf("%d", a+i);

		stack<int> stk;

		int ans = 0;
		for(int i= 1; i< 12; i++){
			if(a[i] > a[i-1]){
				ans ++;
				stk.push(a[i-1]);
			}

			else if(a[i] == a[i-1]) continue;

			else while(stk.size()){
				if(a[i] == stk.top()) break;
				else if(a[i] > stk.top()){
					ans ++;
					break;
				}
				else stk.pop();
			}
		}

		printf("%d\n", ans);
	}

	return 0;
}
