#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <vector>
using namespace std;
int p,k,a[15],ans;
int main()
{
    while(~scanf("%d",&p))
    {
        while(p--)
        {
            scanf("%d",&k);
            for(int i=1;i<=12;++i)
                scanf("%d",a+i);
            ans=0;
            for(int i=2;i<12;++i)
            {
                int m=0x7fffffff;
                for(int j=i;j<12;++j)
                {
                    m=min(m,a[j]);
                    ans+=(m>a[i-1]&&m>a[j+1]);
                }
            }
            printf("%d %d\n",k,ans);
        }
    }
    return 0;
}
