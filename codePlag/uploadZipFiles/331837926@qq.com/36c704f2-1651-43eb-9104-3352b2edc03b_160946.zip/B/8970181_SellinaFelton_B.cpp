#include <stdio.h>
#include <iostream>
#include <string.h>
using namespace std ;
int num[25] ;
int check(int b , int e )
{
    int flag = 1 ;
    for(int i = b ; i <= e ; i ++)
    {
        if(num[i] <= num[b-1] || num[i] <= num[e+1])
        {
            flag = 0;
            break ;
        }
    }
    return flag ;
}
int main()
{
    int n , k ;
    cin >>n ;
    while(n --)
    {
        cin >> k ;
        for(int i = 0 ; i < 12 ; i ++)
            cin >> num[i] ;
        int sum  = 0 ;
        for(int i = 0 ; i < 12 ; i ++)
        {
            for(int j = i ; j < 12 ; j ++)
            {
                if(check(i,j)==1) sum ++ ;
            }
        }
        cout << k << ' '<< sum << endl;
    }
    return 0 ;
}
