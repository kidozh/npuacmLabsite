#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <string>
using namespace std;
int a[13],cnt,k;
int pos[13];
bool vis[13][13];
void dfs(int l,int r)
{
    if (l>r) return;
    int pos=-1;
    vis[l][r]=true;
    for (int i=l;i<=r;i++)
    {
        if (a[i]<=a[l-1] || a[i]<=a[r+1])
        {
            pos=i;
            break;
        }
    }
    if (pos==-1) cnt++;
    if (!vis[l+1][r]) dfs(l+1,r);
    if (!vis[l][r-1]) dfs(l,r-1);
}

int main()
{
    int t;
    cin>>t;
    while (t--)
    {
        cnt=0;
        memset(vis,0,sizeof vis);
        scanf("%d",&k);
        for (int i=0;i<12;i++) scanf("%d",&a[i]);
        dfs(1,10);
        printf("%d %d\n",k,cnt);
    }
    return 0;
}
