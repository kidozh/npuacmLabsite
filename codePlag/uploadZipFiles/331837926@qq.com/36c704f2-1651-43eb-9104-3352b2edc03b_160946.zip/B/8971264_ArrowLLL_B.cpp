#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int maxn(15);
int h[maxn];

int judge(int a, int b)
{
    for(int i = a + 1; i < b; i++)
        if(h[i] <= h[a] || h[i] <= h[b]) return 0;
    return 1;
}

int main()
{
    int T, n = 12;
    //freopen("data.in", "r", stdin);
    scanf("%d", &T);
    while(T--) {
        int t, ans = 0;
        scanf("%d", &t);
        for(int i = 0; i < n; i++) {
            scanf("%d", h + i);
        }
        for(int i = 0; i < n; i++) {
            for(int j = i + 2; j < n; j++)
                ans += judge(i, j);
        }
        printf("%d %d\n", t, ans);
    }
    return 0;
}
