#include <bits/stdc++.h>
using namespace std;

int n, m;
int a[26];

bool check(int l, int r)
{
	for (int i = l; i <= r; ++i)
		if (a[i] <= a[l-1] || a[i] <= a[r+1]) return false;
	return true;
}

int main()
{
	int T, cas;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d", &cas);
		for (int i = 1; i <= 12; ++i) scanf("%d", &a[i]);
		int ans = 0;
		for (int i = 2; i <= 11; ++i)
			for (int j = i; j <= 11; ++j)
				if (check(i, j)) ++ans;
		printf("%d %d\n", cas, ans);
	}
	return 0;
}