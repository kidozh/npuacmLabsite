#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define debug(a) cout<<a<<endl
#define clr(a) memset(a,0,sizeof(a))
#define clrne(a) memset(a,-1,sizeof(a))
#define clrinf(a) memset(a,0x3f,sizeof(a))
#define clrneinf(a) memset(a,0xc0,sizeof(a))
#define pb(a) push_back(a)
#define maxn 10001
#define mod 1000000007
#define eps 1e-9
#define inf 0x7fffffff
int a[30];
int minn(int i,int j)
{
    int ans = a[i];
    for (;i<=j;i++) ans = min(ans,a[i]);
    return ans;
}
int main()
{
//  freopen("in.txt","r",stdin);
//  freopen("out.txt","w",stdout);
    int T;
    scanf("%d",&T);
    while (T--)
    {
        int ans = 0;
        int temp;
        scanf("%d",&temp);
        for (int i  = 1;i<=12;i++)
            scanf("%d",&a[i]);
        for (int i = 2;i<=11;i++)
            for (int j = i;j<=11;j++)
        {

            if (minn(i,j)>a[i-1]&&minn(i,j)>a[j+1])
            {
                ans++;
            }
        }
        cout<<temp<<' '<<ans<<endl;
    }
    return 0;
}
