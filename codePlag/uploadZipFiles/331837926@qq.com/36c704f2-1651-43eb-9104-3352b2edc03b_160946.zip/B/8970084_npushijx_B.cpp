#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

int main ()
{
    int P;
    cin>>P;
    while(P--)
    {
        int K;
        scanf("%d",&K);
        int a[12];
        for(int i=0;i<12;i++)
        {
            scanf("%d",&a[i]);
        }
        int cnt=0;
        for(int i=1;i<11;i++)
        {
            int mi=a[i];
            for(int j=i;j<11;j++)
            {
                if(a[j]<mi) mi=a[j];
                if(mi>a[i-1] && mi>a[j+1])
                {
                    cnt++;
                }
            }
        }
        cout<<K<<' '<<cnt<<endl;
    }
    return 0;
}
