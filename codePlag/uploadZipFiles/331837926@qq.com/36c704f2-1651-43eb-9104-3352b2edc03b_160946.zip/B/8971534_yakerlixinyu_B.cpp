#include <iostream>
#include <cstdio>
using namespace std;
int num=0;
int A[13];
int que;
void  solve(int a,int b,int m)
{
	if((a==b&&A[a]<m)||a>b||m>que||a==0||b==0)
		return ;
		//printf("%d %d %d\n",a,b,m);
	num++;
	int flag=a-1;
	for(int i=a;i<=b;i++)
	{
		if(A[i]==m)
		 {
			solve(flag+1,i-1,m+1);
	        flag=i;
		}

	}
	if(flag==a-1)
		num--;
	solve(flag+1,b,m+1);

}
int main()
{
	int m;

	scanf("%d",&m);
	while(m--)
	{
       num=-1;
       que=0;
		for(int i=0;i<13;i++)
			{
				scanf("%d",&A[i]);
				if(que<A[i])
					que=A[i];
			}
		solve(1,12,0);
		printf("%d %d\n",A[0],num);
	}
	return 0;
}
