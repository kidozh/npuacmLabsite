#include <bits/stdc++.h>
using namespace std;
const int maxn=1e3+10;
int a[maxn];
int check(int l,int r)
{
   int p=a[l];
   for(int i=l;i<=r;i++)p=min(p,a[i]);
   return p;
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        int k;scanf("%d",&k);
        int ans=0;
        for(int i=1;i<=12;i++)scanf("%d",&a[i]);
        for(int i=1;i<=12;i++)
        {
            for(int j=i;j<=12;j++)
            {
                int tep=check(i,j);
                //cout<<i<<" "<<j<<" "<<tep<<endl;
                if(tep<=a[i-1]||tep<=a[j+1])continue;
                ans++;
            }
        }
        printf("%d %d\n",k,ans);
    }
    return 0;
}
