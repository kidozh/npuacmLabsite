#include <cstdio>
void work()
{
 int i,j,s,t;
 int a[21];
 for (i=1;i<=20;i++) scanf("%d",&a[i]);
 s=0;
 for (i=2;i<=20;i++){
      for (j=i;j>1;j--){
	       if (a[j]<a[j-1]){
		       t=a[j-1];a[j-1]=a[j];a[j]=t;
		       s++;
						 }
					   }
					}
 printf("%d\n",s);    
}
int main()
{
 int i,p,k;
 scanf("%d",&p);
 for (i=1;i<=p;i++){
 	  scanf("%d",&k);
 	  printf("%d ",k);
 	  work();
                   }
 return 0;
} 