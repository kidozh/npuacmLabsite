#include<cstdio>
#include<cstring>
#include<algorithm>
#define maxn 20
using namespace std;

int a[maxn+5];

int solve()
{
    int sum=0;
    for(int i=2;i<=20;i++)
    {
        for(int j=1;j<i;j++)
        {
            if(a[j]>a[i]) sum++;
        }
    }
    return sum;
}

int main()
{
    int P;
    scanf("%d",&P);
    for(int i=1;i<=P;i++)
    {
        int id;
        scanf("%d",&id);
        for(int j=1;j<=20;j++)
        {
            scanf("%d",&a[j]);
        }
        printf("%d %d\n",id,solve());
    }
    return 0;
}
