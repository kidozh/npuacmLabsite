#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define lson rt<<1
#define rson rt<<1|1

using namespace std;
int a[25];
int main(){
    int T,cas,n = 20;
    scanf("%d",&T);
    for(cas = 1;cas<=T;cas++){
        int k;
        scanf("%d",&k);
        for(int i=1;i<=n;i++){
            scanf("%d",&a[i]);
        }
        int cnt = 0;
        for(int i=1;i<=n;i++){
            int tmp = a[i];
            for(int j = i+1;j<=n;j++){
                if(a[j] < tmp){
                    cnt ++;
                }
            }
        }
        printf("%d %d\n",k,cnt);
    }
    return 0;
}
