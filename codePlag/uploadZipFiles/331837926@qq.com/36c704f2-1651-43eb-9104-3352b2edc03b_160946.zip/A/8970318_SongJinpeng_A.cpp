#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

using namespace std;

int main()
{
    int n;
    cin>>n;

    int a[30];
    int k,i,j,l;
    int tmp;
    a[0]=-1;
    while(n--)
    {
        cin>>k;
        int sum=0;
        for(i=1;i<=20;i++)
        {
            cin>>a[i];
            j=i-1;
            while(1)
            {
                if(a[j]<a[i])
                {
                    sum+=i-j-1;
                    l=i-1;
                    tmp=a[i];
                    while(l>=j+1)
                    {
                        a[l+1]=a[l];
                        l--;
                    }
                    a[j+1]=tmp;
                    break;
                }
                j--;
            }
            /*for(j=0;j<i;j++)
            {
                if(a[j]>a[i])
                {
                    sum+=i-j;
                    tmp=a[i];
                    for(l=i-1;l>=j;l--)
                    {
                        a[l+1]=a[l];
                    }
                    a[j]=a[i];
                    break;
                }
            }*/
        }
        cout<<k<<' '<<sum<<endl;

    }
    return 0;
}
