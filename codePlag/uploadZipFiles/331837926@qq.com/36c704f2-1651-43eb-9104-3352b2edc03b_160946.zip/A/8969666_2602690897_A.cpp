#include<iostream>
#include<algorithm>
using namespace std;
int p,k,t,arr[20];
int main()
{
    cin>>p;
    for(int i=1;i<=p;i++){
        cin>>t;
        int ans=0;
        for(int j=0;j<20;j++)
        {
            cin>>arr[j];
            for(int k=0;k<j;k++)
            {
                if(arr[k]>arr[j])
                ans++;
            }
        }
        cout<<i<<" "<<ans<<endl;
            
    }
    return 0;
}