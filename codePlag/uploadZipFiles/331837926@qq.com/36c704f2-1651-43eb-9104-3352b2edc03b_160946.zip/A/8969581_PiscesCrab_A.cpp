//By Sean Chen
#include <iostream>
#include <cstdio>
#include <cstring>
#include <map>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;
int T,Case;
int a[25];
int main()
{
    scanf("%d",&T);
    for (int i=0;i<T;i++)
    {
        scanf("%d",&Case);
        int cnt=0;
        for (int i=0;i<20;i++)
        {
            scanf("%d",&a[i]);
            for (int j=0;j<i;j++)
                if (a[j]>a[i])
                    cnt++;
        }
        printf("%d %d\n",Case,cnt);
    }
    return 0;
}
