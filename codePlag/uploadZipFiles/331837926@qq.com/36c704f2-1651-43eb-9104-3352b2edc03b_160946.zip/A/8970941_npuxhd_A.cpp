#include <iostream>
#include<algorithm>
#include<stdio.h>
#include<string.h>
#include<queue>
using namespace std;
int num[25];
bool vis[25];
struct node
{
    int data;
    int ord;
    bool friend operator < (const struct node a,const struct node b)
    {
        return a.data<b.data;
    }
};
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
         priority_queue<node> que;
         int cnt;
         struct node u;
         scanf("%d",&cnt);
         for(int i=1;i<=20;i++)
         {
             scanf("%d",&u.data);
             u.ord=i;
             que.push(u);
             num[i]=i;
             vis[i]=1;
         }
         int ans=0;
         while(!que.empty())
         {
             u=que.top(); que.pop();
             for(int i=u.ord+1;i<=20;i++)
             {
                 ans+=vis[i];
             }
             vis[u.ord]=0;
         }
        printf("%d %d\n",cnt,ans);
    }
    return 0;
}