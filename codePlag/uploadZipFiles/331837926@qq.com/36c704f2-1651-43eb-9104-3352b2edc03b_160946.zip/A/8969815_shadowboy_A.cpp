#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
using namespace std;
int num[30];
int main()
{
    int n;
    scanf("%d",&n);
    for(int cases=1;cases<=n;cases++){
        int tmp;
        int sum=0;
        scanf("%d",&tmp);
        for(int i=1;i<=20;i++){
            scanf("%d",&num[i]);
        }
        for(int i=1;i<=20;i++){
            for(int j=i+1;j<=20;j++){
                if(num[i]>num[j])
                    sum++;
            }
        }
        printf("%d %d\n",cases,sum);

    }
    return 0;
}
