#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;
int ca,a[30];
void init(){
    for(int i = 1; i <= 20 ; i++){
        scanf("%d",&a[i]);
    }
    int ans = 0;
    for(int i = 2; i <= 20 ; i++){
        for(int j = 1; j < i ; j++){
            if(a[j] > a[i])
                ans++;
        }
    }
    printf("%d %d\n",ca,ans);
}

int main(){
    int T;
    scanf("%d",&T);
    for(ca =1 ; ca <= T ;ca++){
        int n;
        scanf("%d",&n);
        init();
    }
}
