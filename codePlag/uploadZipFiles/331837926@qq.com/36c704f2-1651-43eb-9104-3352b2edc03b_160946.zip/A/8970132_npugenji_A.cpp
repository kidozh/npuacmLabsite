#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <string>

using namespace std;
int que[22];
int n,m,cnt,k;


int main()
{
    int t;
    cin>>t;
    while (t--)
    {
        cnt=0;
        scanf("%d",&k);
        for (int i=0;i<20;i++) scanf("%d",&que[i]);
        for (int i=1;i<20;i++)
            for (int j=0;j<i;j++)
                if (que[j]>que[i]) cnt++;
        printf("%d %d\n",k,cnt);
    }
    return 0;
}
