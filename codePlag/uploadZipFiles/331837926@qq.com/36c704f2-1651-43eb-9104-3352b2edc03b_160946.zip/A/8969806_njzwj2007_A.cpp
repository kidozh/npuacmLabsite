#include <bits/stdc++.h>
#define lch p<<1
#define rch p<<1|1
using namespace std;
const int N=105;
int tree[N],n;
pair<int, int> a[N];
void add(int k, int num) { // ?????
    while (k<=n) {
        tree[k]+=num;
        k+=k&-k;
    }
}
int query(int k) { // 1~k???
    int sum=0;
    while (k) {
        sum+=tree[k];
        k-=k&-k;
    }
    return sum;
}
int main(){
    int T,icase=1;
    scanf("%d",&T);
    while (T--){
        memset(tree,0,sizeof tree);
        scanf("%d",&icase);
        n=20;
        for (int i=1;i<=n;++i) add(i,1);
        for (int i=0;i<n;++i){
            int x;scanf("%d",&x);
            a[i]=make_pair(x,i+1);
        }
        sort(a,a+n);
        int ans=0;
        for (int i=0;i<n;++i){
            ans+=query(a[i].second-1);
            add(a[i].second,-1);
        }
        printf("%d %d\n", icase, ans);
    }
    return 0;
}