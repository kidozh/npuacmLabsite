#include <iostream>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
using namespace std;
int a[50];
int dj()
{
    int ans = 0;
    int turn = 0;
    int tu = 0;
    //printf("1\n");
    for(int i=0;i<=19;i++)
    {
        for(int j = i+1;j<=19;j++)
        {
            if(a[i] > a[j]){tu = a[i];a[i] = a[j];a[j] = tu;ans++;
            if(j != 19)j = i;
            }
        }
    }
    return ans;
}
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=1;i<=t;i++)
    {
        int c;
        scanf("%d",&c);
        for(int j=0;j<=19;j++)scanf("%d",&a[j]);
        //for(int j=0;j<=19;j++)printf("%d ",a[j]);
        int ans = 0;
        ans = dj();
        printf("%d %d\n",i,ans);
        memset(a,0,sizeof(a));

    }
    return 0;
}
