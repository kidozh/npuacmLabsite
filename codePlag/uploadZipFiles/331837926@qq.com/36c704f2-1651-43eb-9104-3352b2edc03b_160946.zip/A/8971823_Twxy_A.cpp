#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

int Find(int a[], int n, int x)
{
	int i=0;

	for(i=0; i<n; i++)
		if(a[i]>x)
			return i;

	return i;
}

int main()
{
	int n, th;
	int cnt;
	int height1[20], height2[20];
	int i, j;
	int temp;

	cin >> n;

	while(n--)
	{
		cin >> th;
		cout << th << ' ';

		cnt = 0;

		for(i=0; i<20; i++)
		{
			cin >> height1[i];
			height2[i] = height1[i];
		}

		for(i=0; i<20; i++)
		{
			temp = Find(height1, i, height2[i]);

			for(j=i; j>temp; j--)
			{
				swap(height1[j], height1[j-1]);
				cnt++;
			}

			height1[temp] = height2[i];
		}

		cout << cnt << endl;
	}

	return 0;
}
