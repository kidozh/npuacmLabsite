#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
using namespace std;
int a[25];

int main()
{

    int t,kase,i,cnt,x,j,pos;
    scanf("%d",&t);
    while(t--)
    {
        cnt=0;
        scanf("%d",&kase);
        scanf("%d",&a[0]);
        for(i=1;i<20;i++)
        {
            scanf("%d",&x);
            pos=i;
            for(j=0;j<i;j++)
            {
                if(a[j]>x)
                {
                    pos=j;
                    cnt+=(i-j);
                    break;
                }
            }
            if(pos==i) {a[pos]=x;continue;}
            for(j=i;j>=pos+1;j--)
            {
                a[j]=a[j-1];
            }
            a[pos]=x;
        }
        printf("%d %d\n",kase,cnt);
    }
    return 0;
}
