#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>

using namespace std;

int a [22];

int main ()
{
	int cas;
	cin >> cas;

	while(cas--){
		memset(a, 0, sizeof(a));

		int no;
		cin >> no;
		cout << no << " ";

		int ans = 0;
		for(int i= 0; i< 20; i++){
			int temp;
			cin >> temp;

			int t = upper_bound(a, a+i, temp) - a;
			//cout<< t <<" ";

			for(int j= i; j> t; j--)
				a[j] = a[j-1];
			a[t] = temp;

//			cout << t << "~";
//			for(int m= 0; m< 20; m++)
//				cout << a[m] << " ";
//			cout << endl;

			ans += i - t;
		}

		cout << ans << endl;
	}

	return 0;
}
