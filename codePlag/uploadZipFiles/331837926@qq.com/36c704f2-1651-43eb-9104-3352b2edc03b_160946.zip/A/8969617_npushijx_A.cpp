#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

int main ()
{
    int a[20];
    int N;
    cin>>N;
    for(int n=1;n<=N;n++)
    {
        int K;
        scanf("%d",&K);
        for(int i=0;i<20;i++)
        {
            scanf("%d",&a[i]);
        }
        int cnt=0;
        while(1)
        {
            int flag=1;
            for(int i=19;i>=1;i--)
            {
                if(a[i]<a[i-1])
                {
                    cnt++;
                    swap(a[i],a[i-1]);
                    flag=0;
                }
            }
            if(flag) break;
        }
        cout<<K<<' '<<cnt<<endl;
    }
    return 0;
}
