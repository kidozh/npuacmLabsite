#include<cstdio>
#include<algorithm>
#include<iostream>

using namespace std;
int num[21];
int main()
{
    int n;
    scanf("%d", &n);
    while(n--)
    {
        int t;
        scanf("%d", &t);
        for(int i = 0; i < 20; i++)
        {
            scanf("%d", &num[i]);
        }

        int ans = 0;
        int flag = 0;
        for(int i = 19; i >= 0; i--)
        {
            for(int j = i; j >= 0; j--)
            {
                if(num[i] < num[j])
                {
                    ans++;
                    int temp = num[j];
                    num[j] = num[i];
                    num[i] = temp;
                    flag = 1;
                }

            }
            if(flag)
            {
                i++;
                flag = 0;
            }
        }

        printf("%d %d\n", t, ans);
    }
}
