#include <iostream>
#include <cstdio>
#include <cmath>
#include <string.h>
using namespace std;
int a[100];
int main()
{
    int p;
    cin>>p;
    for(int C=1;C<=p;C++)
    {
        int k;
        cin>>k;
        int s=0;
        for(int i=1;i<=20;i++)
        {
            cin>>a[i];
            for(int j=1;j<=i-1;j++)
                if (a[j]>a[i]) s++;
        }
        cout<<k<<" "<<s<<endl;
    }
    return 0;
}