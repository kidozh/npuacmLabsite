#include<bits/stdc++.h>

#define inf 0x3f3f3f3f

const int maxn=100;

using namespace std;

int t;

int a[maxn+10];

int main()
{
        scanf("%d",&t);
        while(t--){
                int k;
                scanf("%d",&k);
                memset(a,0 ,sizeof(a));
                a[21] = inf;
                a[0] = -1;
                for(int i = 1; i <= 20; ++i){
                        scanf("%d",&a[i]);
                }
                long long ans = 0;
                for(int i = 2; i <= 20; ++i){
                        int temp = 0;
                        int temp1 = 0;
                        int flag = 0;
                        for(int j = i - 1; j >= 1; --j){
                                if(a[j] > a[i]){
                                     flag = 1;
                                     temp = j;
                                     temp1 = a[i];
                                }
                        }
                        if(flag){
                        ans += i - temp;
                        for(int k = i - 1; k >= temp; --k){
                                a[k+1] = a[k];
                        }

                        a[temp] = temp1;
                        }
                }
                printf("%d %lld\n",k,ans);
        }
    return 0;
}
/*
4
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 0
*/
