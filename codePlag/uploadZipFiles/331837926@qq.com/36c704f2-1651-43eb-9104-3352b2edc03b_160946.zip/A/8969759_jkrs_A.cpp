/*jkrs*/
#include <bits/stdc++.h>
#define ff first
#define ss second
#define clr(_x,_y) memset(_x,_y,sizeof (_x))
#define pt(y) push_back(y)
#define mk(x,y) make_pair(x,y)
#define pof() pop_front()
#define pob() pop_back()
#define puf() push_front()
#define ls p << 1
#define rs p << 1 | 1
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int inf = 0x3f3f3f3f;
const ll linf = 1e18;
const double pi = acos(-1.0);
const int MAXN = 1e5 + 10;
const int MAXM = 1e5 + 10;
const double eps = 1e-8;

map <int,bool> mp;
map <int,bool> :: iterator it;

int main()
{
    int t;
    scanf("%d",&t);
    while (t --)
    {
        int k;
        scanf("%d",&k);
        mp.clear();
        int sum = 0;
        for (int i = 0;i < 20; ++ i)
        {
            int x;
            scanf("%d",&x);
            int cur = 0;
            for (it = mp.begin();it != mp.end(); ++ it)
            {
                ++ cur;
                if (x < (it -> ff))
                {
                    sum += mp.size() - cur + 1;
                    break;
                }
            }
            mp[x] = 1;
        }
        printf("%d %d\n",k,sum);
    }
    return 0;
}
