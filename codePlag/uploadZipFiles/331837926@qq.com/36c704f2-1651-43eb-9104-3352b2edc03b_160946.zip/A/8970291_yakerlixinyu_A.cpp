#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int m;
	scanf("%d",&m);
	while(m--)
	{
		int A[21];
		for(int i=0;i<21;i++)
			scanf("%d",&A[i]);
		int num=0;
		for(int i=2;i<=20;i++)
		{
			for(int j=i;j>1;j--)
				if(A[j]<A[j-1])
			{   int s=A[j];
				A[j]=A[j-1];
				A[j-1]=s;
				num++;
			}
		}
        printf("%d %d\n",A[0],num);
	}
	return 0;
}
