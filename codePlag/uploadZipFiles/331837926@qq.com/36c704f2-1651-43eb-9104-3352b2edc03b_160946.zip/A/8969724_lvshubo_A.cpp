#include <iostream>
#include <cstdio>
#include <queue>

using namespace std;
int a[1001][20],step;
void buble_sort(int t)
{
    int flag,i,j,x;
    for(i=0;i<20;i++)
    {
        flag=0;
        for(j=0;j<20-i-1;j++){
            if(a[t][j]>a[t][j+1]){
                x=a[t][j];
                a[t][j]=a[t][j+1];
                a[t][j+1]=x;
                flag=1;
                step++;
            }
        }
        if(!flag)
            break;
    }
}
int main()
{
    int p,i,t;
    while(scanf("%d",&p)!=EOF)
    {
        while(p--){
            step=0;
            scanf("%d",&t);
            for(i=0;i<20;i++){
                scanf("%d",&a[t][i]);
            }
            buble_sort(t);
            printf("%d %d\n",t,step);
        }
    }
    return 0;
}
