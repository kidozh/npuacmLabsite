#include <iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<string.h>
#include<queue>
using namespace std;
long long  s[50];
int main()
{
	int t;
	scanf("%d",&t);
	int k;
	while(t--)
	{
		scanf("%d",&k);
		long long sum=0;
		for(int i=0;i<20;i++)scanf("%lld",&s[i]);
		for(int i=1;i<20;i++)
		{
			for(int j=i-1;j>=0;j--)
			{
				if(s[j]<s[i])
				{
					sum+=(i-j-1);
					break;
				}
			}
			if(s[0]>s[i])
				sum+=i;
				//cout<<sum<<endl;
			sort(s,s+i+1);
		}
		printf("%d %lld\n",k,sum);
	}
	return 0;
}
