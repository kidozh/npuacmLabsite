#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <vector>
using namespace std;
int p,k,a[22],ans;
int main()
{
    while(~scanf("%d",&p))
    {
        while(p--)
        {
            scanf("%d",&k);
            for(int i=1;i<=20;++i)
                scanf("%d",a+i);
            ans=0;
            for(int i=1;i<20;++i)
                for(int j=i+1;j<=20;++j)
                    ans+=a[i]>a[j];
            printf("%d %d\n",k,ans);
        }
    }
    return 0;
}
