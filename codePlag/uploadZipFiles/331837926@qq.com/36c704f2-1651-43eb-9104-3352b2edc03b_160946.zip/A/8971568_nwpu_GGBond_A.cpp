#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<string>
#include<sstream>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<set>
#include<list>
#include<algorithm>
#include<functional>
#include<numeric>

#define lson  rt<<1,l,mid
#define rson  rt<<1|1,mid+1,r
#define rep(i,x,y)  for(int i=x;i<y;i++)
#define rrep(i,x,y)  for(int i=x;i>y;i--)
#define mem(a,x)  memset(a,x,sizeof(a))
#define pb  push_back
#define mp  make_pair
#define fir  first
#define sec  second
#define lb  lower_bound
#define ub  upper_bound

using namespace std;
typedef long long ll;
typedef pair<int,int> p;

//printf("hello world\n");

const int inf=0x3f3f3f3f;

int ncase,n,cnt,res;

int a[25];

void debug(int l,int r){
	for(int i=l;i<=r;i++){
			printf("%d ",a[i]);
		}
	printf("\n");
}

void merge(int fl,int fr,int sl,int sr){
	int l[25];
	int r[25];
	memset(l,0x3f,sizeof(l));
	memset(r,0x3f,sizeof(r));
	for(int i=fl;i<=fr;i++){
		l[i-fl]=a[i];
	}
	for(int i=sl;i<=sr;i++){
		r[i-sl]=a[i];
	}
	int pl=0;
	int pr=0;
    for(int i=fl;i<=sr;i++){
		if(l[pl]<r[pr]){
			a[i]=l[pl++];
		}
		else{
			a[i]=r[pr++];
			res+=fr-fl-pl+1;
		}
    }
}

void tsort(int l,int r){
	if(l>=r) return;
	int mid=(l+r)>>1;
	tsort(l,mid);
	tsort(mid+1,r);
    merge(l,mid,mid+1,r);
}

int main()
{
	scanf("%d",&ncase);
	while(ncase--){
		scanf("%d",&cnt);
		for(int i=0;i<20;i++){
			scanf("%d",&a[i]);
		}
		res=0;
		tsort(0,19);

		printf("%d %d\n",cnt,res);
	}
	return 0;
}
