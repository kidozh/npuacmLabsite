#include<cstdio>
int main()
{
    int T,i,j;
    int s[20],cnt,c;
    scanf("%d",&T);
    for(int t=1;t<=T;t++)
    {
        cnt=0;
        scanf("%d",&t);
        printf("%d ",t);
        for(i=0;i<20;i++)
        {
            scanf("%d",&s[i]);
        }
        for(i=1;i<20;i++)
        {
            for(j=0;j<i;j++)
            {
                if(s[j]>s[i])
                {
                    c=s[i];
                    cnt+=i-j;
                    for(int l=i;l>j;l--)
                    {
                        s[l]=s[l-1];
                    }
                    s[j]=c;
                }
            }
        }
        printf("%d\n",cnt);
    }
    return 0;
}
