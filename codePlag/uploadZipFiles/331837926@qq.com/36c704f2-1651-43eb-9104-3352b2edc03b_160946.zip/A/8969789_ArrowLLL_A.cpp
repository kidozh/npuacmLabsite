#include <iostream>
#include <cstdio>

using namespace std;

int h[22];

int main()
{
    int T;
    //freopen("data.in", "r", stdin);
    scanf("%d", &T);
    while(T--) {
        int t, ans = 0;
        scanf("%d", &t);
        for(int i = 0; i < 20; i++)
            scanf("%d", h + i);
        for(int i = 1; i < 20; i++) {
            for(int j = 0; j < i; j++)
                if(h[j] > h[i]) ans++;
        }
        printf("%d %d\n", t, ans);
    }
}
