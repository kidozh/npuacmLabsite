#include <bits/stdc++.h>
using namespace std;

int n, cas;
int a[25];

int main()
{
	int T;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d", &cas);
		for (int i = 1; i <= 20; ++i) scanf("%d", &a[i]);
		int ans = 0;
		for (int i = 1; i < 20; ++i)
			for (int j = i + 1; j <= 20; ++j)
				if (a[i] > a[j]) ++ans;
		printf("%d %d\n", cas, ans);
	}
	return 0;
}