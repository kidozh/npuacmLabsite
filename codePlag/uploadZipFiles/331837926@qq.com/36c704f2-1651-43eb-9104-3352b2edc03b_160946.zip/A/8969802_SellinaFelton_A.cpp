#include <stdio.h>
#include <iostream>
#include <string.h>
using namespace std ;
#define MAX 25
int num[MAX] ;
int main()
{
    int n , k ;
    cin >> n ;
    while(n--)
    {
        cin >> k ;
        for(int i = 0 ; i < 20 ; i ++)
        {
            cin >> num[i] ;
        }
        int cnt = 0 ;
        for(int i = 0 ; i < 20 ; i ++)
        {
            for(int j = i+1 ; j < 20 ; j ++)
            {
                if(num[j] < num[i]) cnt++;
            }
        }
        cout << k << ' '<< cnt<<endl;
    }
    return 0 ;
}
