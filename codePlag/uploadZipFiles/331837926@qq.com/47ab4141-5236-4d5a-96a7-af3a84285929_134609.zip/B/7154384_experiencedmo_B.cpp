#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <stdlib.h>
#include <stack>
#include <vector>
#include <string.h>
#include <queue>
#include <math.h>
#define msc(X) memset(X,-1,sizeof(X))
#define ms(X) memset(X,0,sizeof(X))
typedef long long LL;
using namespace std;

const int MAXN=15;
const double eps=1e-7;
double a[MAXN][MAXN];
int equ;
int Guass(void)
{
	int i,j,k,col,max_r;
	for(k=col=0;k<equ&&col<equ;k++,col++)
	{
		max_r=k;
		for(i=k+1;i<equ;i++)
			if(fabs(a[i][col])>fabs(a[max_r][col]))
				max_r=i;
		if(fabs(a[max_r][col])<eps) return 1;
		if(k!=max_r)
			for(j=col;j<equ;j++)
				swap(a[k][j],a[max_r][j]);
		for(j=col+1;j<equ;j++) a[k][j]/=a[k][col];
		a[k][col]=1;
		for(i=0;i<equ;i++)
			if(i!=k){
				for(j=col+1;j<equ;j++)
					a[i][j]-=a[k][j]*a[i][col];
				a[i][col]=0;
			}
	}
	return 0;
}
int main(int argc, char const *argv[])
{
	int n;
	scanf("%d",&n);
	for(int ti=1;ti<=n;ti++)
	{
		scanf("%d",&equ);
		ms(a);
		for(int i=0;i<equ;i++)
			{
				for(int j=0;j<equ;j++)
					scanf("%lf",a[i]+j);
				a[i][i]-=1.0;
			}
		printf("%d",Guass() );
		if(ti!=n) printf("%c",ti%5==0?'\n':' ' );
	}
	putchar('\n');
	return 0;
}
/*
6
2
4  -2
-6  5
2
2  2
0  0
3
0.3  0.2  0.5
0.4  0.4  0.2
0  0.8  0.2
3
0.3  0.2  0.5
0  0  0
0  0.8  0.2
2
4  2.0
-6  5
2
1  0
0  1
*/