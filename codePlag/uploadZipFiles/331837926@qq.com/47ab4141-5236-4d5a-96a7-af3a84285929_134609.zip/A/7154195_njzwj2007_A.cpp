#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 110;
int n, dp[N][N];
char str[N];

int main() {
    int T;
    scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        scanf("%s", str);
        memset(dp, 0, sizeof dp);
        for (int k=2;k<=n;++k) {
            for (int i=0;i<=n-k;++i) {
                int j=i+k-1;
                if (str[i]=='('&&str[j]==')') {
                    dp[i][j]=dp[i+1][j-1];
                }else if (str[i]==')'&&str[j]=='(') {
                    dp[i][j]=dp[i+1][j-1]+2;
                }else dp[i][j]=dp[i+1][j-1]+1;
                for (int p=i+1;p<j;p+=2) {
                    dp[i][j]=min(dp[i][j], dp[i][p]+dp[p+1][j]);
                }
            }
        }
        printf("%d\n", dp[0][n-1]);
    }
    return 0;
}
