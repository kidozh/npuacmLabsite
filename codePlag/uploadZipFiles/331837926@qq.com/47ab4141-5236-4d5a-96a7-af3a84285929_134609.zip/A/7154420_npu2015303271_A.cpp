#include<iostream>
#include<string>
using namespace std;
int n;
bool flag;
int ans;
string s;
string S = "(()())()()()(())()";
bool judge()
{
	int l = 0, r = 0;
	for (int i = 0; i < n; i++)
	{
		if (r > l)
		{
			return false;
		}
		//cout << l << " " << r << endl;
		if (s[i] == '(')
		{
			l++;
		}
		if (s[i] == ')')
		{
			r++;
		}
	}
	if (l == r)
	{
		return true;
	}
	return false;
}
void dfs(int cnt,int cur)
{
	
	if (judge())
	{
		
		ans = cur;
		flag = true;
		return;
	}
	if (cnt >= n)
	{

		return;
	}
	if (s[cnt] == '(')
	{
		s[cnt] = ')';
		dfs(cnt + 1,cur+1);
		s[cnt] = '(';
		dfs(cnt + 1,cur);
	}
	else
	{
		s[cnt] = '(';
		dfs(cnt + 1,cur+1);
		s[cnt] = ')';
		dfs(cnt + 1,cur);
	}

}
int main()
{
	int T;
	
	cin >> T;
	
	while (T--)
	{
		flag = false;
		cin >> n;
	    cin>>s;
		dfs(0,0);
		if (flag)
		{
      	cout << ans << endl;
		}
	
	}
	return 0;
}
