#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
using namespace std;
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        int n;
        cin>>n;
        string str;
        cin>>str;
        int ans=0,left=0;
        for(int i=0;i<n;i++)
        {
            if(str[i]=='(')
                left++;
            else if(left)
                left--;
            else
                left++,ans++;
        }
        cout<<left/2+ans<<endl;
    }
    return 0;
}
