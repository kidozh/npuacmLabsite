#include <cstdio>
#include <stack>
#include <cstring>
using namespace std;
char str[10005];
int main()
{
    int T;
    scanf("%d",&T);
    for(int i=1;i<=T;i++)
    {
        int len;
        scanf("%d",&len);
        scanf("%s",str);
        stack<char> sta;
        while (!sta.empty()) sta.pop();
        for(int i = 0;i < len; i++)
            if (str[i]==')'&&!sta.empty()&&sta.top()=='(')
                sta.pop();
            else
                sta.push(str[i]);
        int ans=0;
        char c='\0';
        while(!sta.empty())
        {
            if (c=='\0') c=sta.top();
            else
            {
                if (c=='(')
                    if (sta.top()=='(') ans++;else ans+=2;
                else
                    if (sta.top()==')') ans++;else ans+=2;
                c='\0';
            }
            sta.pop();
        }
        printf("%d\n",ans);
    }
    return 0;
}