#include <stdio.h>
#include <algorithm>
#include <math.h>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <iostream>
#include <stack>
#include <string.h>
#include <map>
#include <queue>
#define ll __int64
#include<cstdlib>
#include<algorithm>
#include<list>
#include<vector>
#define mz(a) memset(a,0,sizeof(a))
#define inf 1111111
#define up(i,x,n) for(int i=x;i<=n;i++)
#define down(i,x,n) for(int i=x;i>=n;i--)
#define N 110
using namespace std;
int n;
string s;
int dp[N][N];
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        memset(dp,inf,sizeof(dp));
        scanf("%d",&n);
        int l=0,r=0,ans=0;
        cin>>s;
        up(i,0,n-1)
        {
            if(s[i]=='(')
                l++;
            else
                r++;
            if(l<r)
            {
                l++;
                r--;
                ans++;
            }
        }
        while(l>r)
        {
            l--;
            r++;
            ans++;
        }
        cout<<ans<<endl;
    }
}
