#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#define MAX 105
using namespace std;
int main()
{
    int T;
    cin>>T;
    while(T--){
        int n;
        char s[MAX];
        cin>>n;
        cin>>s;
        int lp=0,rp=0;
        for(int i=0;i<strlen(s);i++){
            if(s[i]=='(')lp++;
            else{
                if(lp!=0)lp--;
                else rp++;
            }
        }
        cout<<(lp+1)/2+(rp+1)/2<<endl;
    }
    return 0;
}
