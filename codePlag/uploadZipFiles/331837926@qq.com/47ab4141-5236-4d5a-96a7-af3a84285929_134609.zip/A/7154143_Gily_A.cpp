#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--) {
        int n;
        string p;
        cin >> n >> p;
        stack<int> s;
        int cnt = 0;
        for (int i = 0; i < n; i++) {
            int now;
            if (p[i] == '(') now = 1;
            if (p[i] == ')') now = 2;
            if (now == 1) {
                s.push(now);
            } else if (now == 2) {
                if (!s.empty()) {
                    s.pop();
                } else {
                    cnt++;
                    s.push(1);
                }
            }
        }
        int cnt1 = 0;
        if (!s.empty()) {
            cnt += s.size() / 2;
        }
        printf ("%d\n", cnt);
    }
    return 0;
}
