#include<iostream>
#include<string.h>
using namespace std;

char ch[110];
int f[110][110],n;

int work(char a,char b)
{
	if(a=='('&&b==')') return 0;
	if(a==b) return 1;
	return 2;
}

int main()
{
	int T;
	cin>>T;
	while(T--)
	{
		int i,j,len,k;
		memset(ch,0,sizeof(ch));
		memset(f,0,sizeof(f));
		cin>>n;
		for(i=0;i<n;i++) cin>>ch[i];
		for(len=2;len<=n;len+=2)
			for(i=0;len+i<=n;i++)
		{
			j=i+len-1;
			f[i][j]=f[i+1][j-1]+work(ch[i],ch[j]);
			for(k=i+1;k+1<j;k+=2)
			{
				//cout<<i<<' '<<k<<' '<<k+1<<' '<<j<<endl;
				f[i][j]=min(f[i][j],f[i][k]+f[k+1][j]);
			}
			//cout<<i<<' '<<j<<' '<<f[i][j]<<endl;
		}
		cout<<f[0][n-1]<<endl;
	}
}
