#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<stack>
using namespace std;
char s[10005];
int main()
{
    int n,m,T;
    scanf("%d",&T);
    while(T--)
    {
        int let=0,right=0;
        scanf("%d",&n);
        scanf("%s",s);
        for(int i=0;i<n;i++)
        {
            if(s[i]=='(') let++;
            else
            {
                if(let)
                let--;
                else right++;
            }
        }
        if(let%2==0)
        printf("%d\n",(let+right)/2);
        else
        {
            if(let<right) swap(let,right);
            printf("%d\n",(let-right)/2+right*2);
        }

    }
    //printf("\n");
}
