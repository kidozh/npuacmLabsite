#pragma warning(disable:4996)
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <queue>
#include <algorithm>
#include <cmath>
#include <string>
#include <map>
#include <cmath>
#include<stack>
#define lpd(a,i,n) for(int i=a;i<=n;i++)
#define clr(a,b) memset(a,b,sizeof(a))
using namespace std;

int main(void)
{
	int t;
	cin >> t;
	while (t--)
	{
		int n;
		scanf("%d", &n);
		string s;
		cin >> s;
		stack<char> p;
		for (int i = 0; i < n; i++)
		{
			if (p.empty())p.push(s[i]);
			else {
				if (p.top() == '('&&s[i] == ')')p.pop();
				else p.push(s[i]);
			}
		}

		int ans = 0;

		char a, b;
		
		while (!p.empty())
		{
			a = p.top();
			p.pop();
			b = p.top();
			p.pop();
			if (a == b)ans++;
			else ans += 2;
			if (p.empty())break;
		
		}

		cout << ans << endl;




		/*if (p.size() == 2)
		{
			char a, b;
			a = p.top(); p.pop();
			b = p.top();
			if (a == '('&&b == ')')cout << 2 << endl;
			else cout << 1 << endl;

		}
		else cout << p.size() / 2 << endl;*/
	}
}