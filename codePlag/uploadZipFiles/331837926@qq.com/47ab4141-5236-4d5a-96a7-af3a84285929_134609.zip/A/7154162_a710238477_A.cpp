#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<climits>
#include<cstring>
#include<map>
#include<string>
#include<ctime>
#include<stack>
#include<queue>
using namespace std;
int times,n,now,op;
char tmp;
int main()
{
	scanf("%d",&times);
	while(times--){
		scanf("%d%*c",&n);
		now=0,op=0;
		for(int i=1;i<=n;i++){
			scanf("%c",&tmp);
			if(tmp=='(') now++;
			else{
				now--;
				if(now<0) now+=2,op++;
			}
		}
		op+=(now/2);
		printf("%d\n",op);
	}
}