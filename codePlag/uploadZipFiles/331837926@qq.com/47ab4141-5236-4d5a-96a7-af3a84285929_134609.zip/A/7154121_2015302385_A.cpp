#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <queue>
#include <queue>
#include <stack>

using namespace std;
char a[110];
int main()
{
        int kase;
        cin>>kase;
        while(kase--)
        {
                int n,cnt=0,cnt1=0;
                cin>>n;
                scanf("%s",a);
                stack <char> q;
                for(int i=0;i<n;)
                {
                        if(a[i]=='(')
                        {
                                q.push('(');
                                cnt1++;
                                i++;
                        }
                        else
                        {
                                if(!q.empty())
                                {
                                        if(q.top()=='(')
                                        {
                                                cnt1--;
                                                q.pop();
                                                i++;
                                        }
                                }
                                else
                                {
                                        q.push('(');
                                        cnt++;
                                        cnt1++;
                                        i++;
                                }
                        }
                }
                cout<<cnt+cnt1/2<<endl;

        }
    return 0;
}
