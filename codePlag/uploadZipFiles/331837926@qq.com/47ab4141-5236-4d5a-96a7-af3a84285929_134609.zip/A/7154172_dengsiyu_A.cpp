#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define debug(a) cout<<a<<endl
#define clr(a) memset(a,0,sizeof(a))
#define clrne(a) memset(a,-1,sizeof(a))
#define clrinf(a) memset(a,0x3f,sizeof(a))
#define clrneinf(a) memset(a,0xc0,sizeof(a))
#define pb(a) push_back(a)
#define maxn 10001
#define mod 1000000007
#define eps 1e-9
#define inf 0x3f3f3f3f
int dp[110][110];
char s[110];
int main()
{
//  freopen("in.txt","r",stdin);
//  freopen("out.txt","w",stdout);
    int T;
    scanf("%d",&T);
    while (T--)
    {
        int n;
        scanf("%d",&n);
        int i,j;
        clrinf(dp);
        for (i = 1;i<=n;i++)
        {
            scanf(" %c",&s[i]);
        }
        dp[0][0] = 0;
        for (i=1; i<=n; i++)
        {
            for (j=0; j<=100; j++)
            {
                if (s[i]=='(')
                {
                    dp[i][j+1] = min( dp[i][j+1],dp[i-1][j]);
                    if (j-1>=0) dp[i][j-1] = min( dp[i][j-1],dp[i-1][j]+1);
                }
                if (s[i]==')')
                {
                    if (j-1>=0) dp[i][j-1] = min( dp[i][j-1],dp[i-1][j]);
                    dp[i][j+1] = min( dp[i][j+1],dp[i-1][j]+1);
                }
            }
        }
//        for (i=0;i<n;i++)
//        {
//            for (j=0;j<n;j++)
//                printf("%d ",dp[i][j]);
//            printf("\n");
//        }
        printf("%d\n",dp[n][0]);
    }
    return 0;
}
