#include <stdio.h>
#include <algorithm>
#include <math.h>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <iostream>
#include <stack>
#include <string.h>
#include <map>
#include <queue>
#define ll __int64
#include<cstdlib>
#include<algorithm>
#include<list>
#include<vector>
#define mz(a) memset(a,0,sizeof(a))
#define inf 10000
#define up(i,x,n) for(int i=x;i<=n;i++)
#define down(i,x,n) for(int i=x;i>=n;i--)
#define N 110
using namespace std;
int n;
char a[110];
int dp[N][N];
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        memset(dp,inf,sizeof(dp));
        scanf("%d",&n);
        up(i,1,n)
        {
            cin>>a[i];
        }
        dp[0][0]=0;
        for(int i=1;i<=n;i++)
        {
            for(int j=0;j<=i;j++)
            {
                if(a[i]=='(')
                {
                    if(j>0)
                    dp[i][j]=min(dp[i-1][j-1],dp[i][j]);
                    dp[i][j]=min(dp[i][j],dp[i-1][j+1]+1);
                }
                else if(a[i]==')')
                {
                    if(j>0)
                    dp[i][j]=min(dp[i][j],dp[i-1][j-1]+1);
                    dp[i][j]=min(dp[i][j],dp[i-1][j+1]);
                }
                //cout<<i<<' '<<dp[i][j]<<endl;
            }
        }
        cout<<dp[n][0]<<endl;
    }
}
