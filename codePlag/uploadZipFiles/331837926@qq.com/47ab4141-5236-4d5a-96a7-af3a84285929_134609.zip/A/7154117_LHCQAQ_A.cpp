#include <bits/stdc++.h>
#define _xx ios_base::sync_with_stdio(0);cin.tie(0);
#define INFB (0x3fffffffffffffff)
#define INFS (0x3fffffff)
#define MAXN (10000)
#define lson (id<<1)
#define rson ((id<<1)|1)
#define mid ((l + r)>>1)
using namespace std;
typedef long long ll;
stack<char> s;
string sn;
int main()
{
    int T;
    cin >> T;
    while(T--)
    {
        int t;
        cin >> t >> sn;
        while(!s.empty()) s.pop();
        for(int i = 0; i < sn.size(); i++)
        {
            if(s.empty()) s.push(sn[i]);
            else if(sn[i] == ')' && s.top() == '(') s.pop();
            else s.push(sn[i]);
        }
        if(s.empty())
        {
            cout << 0 << endl;
            continue;
        }
        int a= 0, b = 0;
        while(!s.empty())
        {
            if(s.top() == ')') a++;
            else  b++;
            s.pop();
        }
        int ans = a/2 + b/2;
        a %= 2;
        b %= 2;
        if(a == 1 && b == 1) ans += 2;
        cout << ans << endl;
    }
    return 0;
}
