#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stack>
#include<algorithm>
#include<iostream>
using namespace std;
const int N = 101;
stack<char> s;
char ch[N];
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
    	int n,i,k=0,ans=0;

        while(!s.empty())
            s.pop();
        scanf("%d",&n);

        scanf("%s",ch);

        for(i=0;i<n;i++)
            if(ch[i]=='(')
			{
				s.push('(');
				k++;
			}
		    else if(!s.empty()&&s.top()=='(')
			{
				s.pop();
                k--;
			}

            else
			{
				s.push('(');
				ans++;
				k++;
			}

        printf("%d\n",ans+=k/2);
    }
    return 0;
}
